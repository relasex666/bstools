"""Append a private menu provider to binary AXML without changing existing attributes."""
import struct


def chunks(data, start=8):
    position = start
    while position < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, position)
        if size < header or position + size > len(data):
            raise ValueError('Invalid AXML chunk')
        yield kind, data[position:position + size]
        position += size
    if position != len(data):
        raise ValueError('Invalid AXML length')


def short_length(value):
    if value >= 32768:
        raise ValueError('String too long')
    return bytes((0x80 | (value >> 8), value & 255)) if value >= 128 else bytes((value,))


def pool_strings(pool):
    count, styles, flags, start, style_start = struct.unpack_from('<IIIII', pool, 8)
    offsets = struct.unpack_from('<' + 'I' * count, pool, 28)
    values = []
    for offset in offsets:
        pos = start + offset
        if flags & 0x100:
            for _ in range(2):
                length = pool[pos]; pos += 1
                if length & 128:
                    length = ((length & 127) << 8) | pool[pos]; pos += 1
            values.append(pool[pos:pos + length].decode('utf-8'))
        else:
            length = struct.unpack_from('<H', pool, pos)[0]; pos += 2
            if length & 32768:
                length = ((length & 32767) << 16) | struct.unpack_from('<H', pool, pos)[0]; pos += 2
            values.append(pool[pos:pos + length * 2].decode('utf-16-le'))
    return values


def rebuild_pool(pool, values):
    _, styles, flags, _, old_style_start = struct.unpack_from('<IIIII', pool, 8)
    original_count = struct.unpack_from('<I', pool, 8)[0]
    style_offsets = pool[28 + original_count * 4:28 + (original_count + styles) * 4]
    style_data = pool[old_style_start:] if old_style_start else b''
    blob = bytearray(); offsets = []
    for value in values:
        offsets.append(len(blob))
        utf16 = value.encode('utf-16-le')
        if flags & 0x100:
            encoded = value.encode('utf-8')
            blob += short_length(len(utf16) // 2) + short_length(len(encoded)) + encoded + b'\0'
        else:
            if len(utf16) // 2 >= 32768:
                raise ValueError('Long UTF16 string unsupported')
            blob += struct.pack('<H', len(utf16) // 2) + utf16 + b'\0\0'
    blob += b'\0' * (-len(blob) % 4)
    start = 28 + len(offsets) * 4 + len(style_offsets)
    style_start = start + len(blob) if style_data else 0
    size = start + len(blob) + len(style_data)
    return (struct.pack('<HHIIIIII', 1, 28, size, len(values), styles, flags & ~1, start, style_start)
            + struct.pack('<' + 'I' * len(offsets), *offsets) + style_offsets + blob + style_data)


def patch(data):
    if struct.unpack_from('<HH', data) != (3, 8):
        raise ValueError('Not binary Android XML')
    parts = list(chunks(data))
    pool = next(blob for kind, blob in parts if kind == 1)
    values = pool_strings(pool)
    original_values = list(values)
    resource_map = next(blob for kind, blob in parts if kind == 0x180)
    ids = struct.unpack_from('<' + 'I' * ((len(resource_map)-8)//4), resource_map, 8)
    def index(value):
        if value not in values:
            values.append(value)
        return values.index(value)
    def attribute_name(resource_id):
        return ids.index(resource_id)
    android = index('http://schemas.android.com/apk/res/android')
    provider = index('provider')
    provider_name = index('com.local.bstools.MenuProvider')
    authority = index('com.supercell.brawlstars.bstools.local')
    attributes = [
        struct.pack('<IIIII', android, attribute_name(0x01010003), provider_name, 0x03000008, provider_name),
        struct.pack('<IIIII', android, attribute_name(0x01010010), 0xffffffff, 0x12000008, 0),
        struct.pack('<IIIII', android, attribute_name(0x01010018), authority, 0x03000008, authority),
    ]
    node = (struct.pack('<HHIII', 0x102, 16, 36+len(attributes)*20, 0, 0xffffffff)
            + struct.pack('<IIHHHHHH', 0xffffffff, provider, 20, 20, len(attributes), 0, 0, 0)
            + b''.join(attributes)
            + struct.pack('<HHIIIII', 0x103, 16, 24, 0, 0xffffffff, 0xffffffff, provider))
    body = bytearray(); inserted = False
    for kind, blob in parts:
        if kind == 1:
            blob = rebuild_pool(blob, values)
        elif kind == 0x103:
            name = struct.unpack_from('<I', blob, 20)[0]
            if original_values[name] == 'application':
                if inserted:
                    raise ValueError('Multiple applications')
                body += node; inserted = True
        body += blob
    if not inserted:
        raise ValueError('No application element')
    result = struct.pack('<HHI', 3, 8, len(body) + 8) + body
    new_pool = next(blob for kind, blob in chunks(result) if kind == 1)
    if pool_strings(new_pool)[:len(original_values)] != original_values:
        raise ValueError('Original string indices changed')
    return result
