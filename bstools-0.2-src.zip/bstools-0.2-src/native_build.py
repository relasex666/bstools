from pathlib import Path
import hashlib
import subprocess

ROOT=Path(__file__).resolve().parent
from build_config import SDK, NDK, CMAKE, INPUT
import zipfile

def run(args):
    subprocess.run([str(x) for x in args],check=True)

def build_native(output):
    with zipfile.ZipFile(INPUT) as apk:
        data = apk.read('lib/arm64-v8a/libg.so')
    if hashlib.sha256(data).hexdigest()!='090d71be3b04fa5d260c7baa94d1cf29834dd9202e4d7f9fd20535afae4ca95b':
        raise ValueError('Game module does not match the 69.230 profile')
    signature=data[0xb2d678:0xb2d678+24]
    (ROOT/'native/aim_signature.h').write_text('#pragma once\nstatic const unsigned char kAimSignature[] = {'+
        ','.join(hex(x) for x in signature)+'};\n'+
        'static const unsigned char kUpdateSignature[] = {'+
        ','.join(hex(x) for x in data[0xf83fd8:0xf83fd8+24])+'};\n'+
        'static const unsigned char kFireSignature[] = {'+
        ','.join(hex(x) for x in data[0xb3c544:0xb3c544+24])+'};\n'+
        'static const unsigned char kSightSignature[] = {'+
        ','.join(hex(x) for x in data[0xd993f4:0xd993f4+24])+'};\n'+
        ''.join('static const unsigned char '+name+'[] = {'+','.join(hex(x) for x in data[addr:addr+24])+'};\n'
            for name,addr in [('kAllocateSignature',0x11a1900),('kConstructSignature',0xf4752c),
                ('kQueueSignature',0xaa173c),('kPredictSignature',0xf860a0),('kMoveSightSignature',0xd99394),
                ('kRangeReaderSignature',0xe57a08),('kCsvIntSignature',0x5324f4),
                ('kObjectDataSignature',0xeb0cc0),('kProjectileRadiusSignature',0xe44a10),
                ('kCharacterRadiusStoreSignature',0xdf14d8)]),encoding='utf-8')
    build=ROOT/'build/dobby-stable'
    run([CMAKE,'-S',ROOT/'third_party/Dobby-stable','-B',build,'-G','Ninja',
        '-DCMAKE_MAKE_PROGRAM='+str(SDK/'cmake/4.1.2/bin/ninja.exe'),
        '-DCMAKE_TOOLCHAIN_FILE='+str(NDK/'build/cmake/android.toolchain.cmake'),
        '-DANDROID_ABI=arm64-v8a','-DANDROID_PLATFORM=android-32','-DCMAKE_BUILD_TYPE=Release',
        '-DDOBBY_DEBUG=OFF','-DPlugin.SymbolResolver=OFF','-DNearBranch=ON'])
    run([CMAKE,'--build',build,'--target','dobby_static','-j','4'])
    toolchain=NDK/'toolchains/llvm/prebuilt/windows-x86_64'
    run([toolchain/'bin/clang++.exe','--target=aarch64-linux-android32',
        '--sysroot='+str(toolchain/'sysroot'),'-std=c++17','-O2','-fPIC','-shared',
        '-fno-exceptions','-fno-rtti','-static-libstdc++','-Wl,--no-undefined',
        '-Wl,-Bsymbolic-functions','-Wl,--exclude-libs,ALL','-Wl,-z,max-page-size=16384',
        '-I'+str(ROOT/'third_party/Dobby-stable/include'),
        ROOT/'native/reader.cpp',ROOT/'native/aimbot.cpp',build/'libdobby.a','-llog','-ldl','-o',output])

if __name__=='__main__':
    destination=ROOT/'build/aim-component'
    destination.mkdir(exist_ok=True)
    build_native(destination/'libbstools_readonly.so')
