#include <jni.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <sys/uio.h>

// Kernel-mediated reads avoid dereferencing stale pointers during respawn.
static bool read_bytes(uint64_t address, void* out, size_t size) {
    if (!address) return false;
    iovec local{out, size}, remote{reinterpret_cast<void*>(address), size};
    return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == static_cast<ssize_t>(size);
}
template<class T> static bool read_at(int fd, uint64_t address, T& out) {
    return read_bytes(address, &out, sizeof(T));
}
static uint64_t module_base() {
    FILE* maps = fopen("/proc/self/maps", "r");
    if (!maps) return 0;
    char line[2048]; uint64_t result = 0;
    while (fgets(line, sizeof(line), maps)) {
        unsigned long long start = 0, offset = 0;
        if (strstr(line, "/libg.so") && sscanf(line, "%llx-%*llx %*4s %llx", &start, &offset) == 2 && offset == 0) {
            result = start; break;
        }
    }
    fclose(maps); return result;
}
uint64_t bstools_module_base() { return module_base(); }
bool bstools_read(uint64_t address,void* output,size_t size) { return read_bytes(address,output,size); }

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_snapshot(JNIEnv* env, jclass) {
    auto status = [&](const char* text) {
        char result[256]; snprintf(result, sizeof(result), "{\"status\":\"%s\"}", text);
        return env->NewStringUTF(result);
    };
    uint64_t base = module_base();
    if (!base) return status("Oyun verisi bekleniyor");
    int fd = -1; // Kept as an internal read_at argument; no proc-mem descriptor is used.
    const uint32_t expected[] = {0xb9403000, 0xd65f03c0, 0xb9403400, 0xd65f03c0, 0xb9403800, 0xd65f03c0};
    uint32_t actual[6]{};
    if (!read_bytes(base + 0xeb101c, actual, sizeof(actual)))
        return status("Bu ortamda okuma izni yok");
    if (memcmp(expected, actual, sizeof(actual)))
        return status("Oyun surumu bu profile uymuyor");
    uint64_t manager=0, screen=0, battle=0, objects=0, array=0;
    int32_t screen_type=0, count=0; uint32_t own_id=0;
    if (!read_at(fd,base+0x1306e50,manager) || !read_at(fd,manager+0x50,screen_type) || screen_type != 5)
        return status("Maca veya antrenmana gir");
    if (!read_at(fd,manager+0x48,screen) || !read_at(fd,screen+0x28,battle)
        || !read_at(fd,battle+0x28,objects) || !read_at(fd,battle+0x100,own_id)
        || !read_at(fd,objects+0xc,count) || !read_at(fd,objects,array) || count<0 || count>2000)
        return status("Karakter bekleniyor");
    for (int i=0; i<count; ++i) {
        uint64_t object=0; uint32_t id=0;
        if (!read_at(fd,array+8ULL*i,object) || !read_at(fd,object+8,id) || id!=own_id) continue;
        int32_t x=0,y=0,hp=0,max_hp=0;
        if (!read_at(fd,object+0x30,x) || !read_at(fd,object+0x34,y)
            || !read_at(fd,object+0xc4,hp) || !read_at(fd,object+0xc8,max_hp)) continue;
        if (hp<0 || max_hp<1 || hp>max_hp || max_hp>1000000) return status("Karakter verisi yenileniyor");
        char result[256];
        snprintf(result,sizeof(result),"{\"x\":%d,\"y\":%d,\"health\":%d,\"maxHealth\":%d}",x,y,hp,max_hp);
        return env->NewStringUTF(result);
    }
    return status("Karakter bekleniyor");
}
