#pragma once
#include <cstdint>

// 69.230: E57A08 -> 533A70 -> 5324F4. All reads use the guarded reader.
namespace bs_metadata {
template<class Read>
int casting_range(Read read,uint64_t base,uint64_t skill){
    uint64_t data=0,row=0,table=0,columns=0,column=0,values=0;
    int32_t index=-1,col=-1,units=0;uint8_t alternate=0;
    if(!skill || !read(skill,data) || !data || !read(skill+34,alternate))return 0;
    // ECE8CC selects the alternate data at +0x260 for the active form.
    if(alternate){
        uint64_t alt=0;int32_t kind=0;uint8_t hyper=0;
        if(!read(data+0x260,alt) || !read(data+516,kind))return 0;
        if(alt){
            if((kind&~1)==2)data=alt;
            else{if(!read(skill+38,hyper))return 0;if(hyper)data=alt;}
        }
    }
    if(!read(base+0x1243c58,col) || col<0 || col>4095
        || !read(data+8,row) || !row || !read(row,table) || !table
        || !read(row+8,index) || index<0 || index>65535
        || !read(table+0x38,columns) || !columns
        || !read(columns+8ULL*col,column) || !column
        || !read(column+0x18,values) || !values
        || !read(values+4ULL*index,units) || units<=0 || units>1000)return 0;
    return units*100;
}
template<class Read>
bool radius(Read read,uint64_t object,uint32_t offset,int maximum,int& output){
    uint64_t data=0;int32_t value=-1;
    if(!read(object+0x10,data) || !data || !read(data+offset,value) || value<0 || value>maximum)return false;
    output=value;return true;
}
}
