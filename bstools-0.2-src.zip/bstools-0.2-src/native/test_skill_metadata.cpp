#include "skill_metadata.h"
#include <unordered_map>
#include <cstring>
#include <iostream>
#include <cstdlib>

std::unordered_map<uint64_t,unsigned char> memory;
template<class T>void put(uint64_t address,T value){
    const auto* bytes=reinterpret_cast<const unsigned char*>(&value);
    for(size_t i=0;i<sizeof(T);++i)memory[address+i]=bytes[i];
}
struct Read {
    template<class T>bool operator()(uint64_t address,T& value)const{
        unsigned char bytes[sizeof(T)]{};
        for(size_t i=0;i<sizeof(T);++i){auto it=memory.find(address+i);if(it==memory.end())return false;bytes[i]=it->second;}
        std::memcpy(&value,bytes,sizeof(T));return true;
    }
};
unsigned passed=0;
void check(const char* name,bool condition){
    if(!condition){std::cerr<<"FAIL "<<name<<'\n';std::exit(1);}
    std::cout<<"PASS "<<name<<'\n';++passed;
}
int main(){
    constexpr uint64_t skill=0x1000,data=0x2000,row=0x3000,table=0x4000,columns=0x5000,column=0x6000,values=0x7000,alternate=0x8000;
    put(skill,data);put<uint8_t>(skill+34,0);put(data+8,row);put(row,table);put<int32_t>(row+8,2);
    put<int32_t>(0x1243c58,3);put(table+0x38,columns);put(columns+24,column);put(column+0x18,values);
    auto range=[=](){return bs_metadata::casting_range(Read{},0,skill);};
    put<int32_t>(values+8,23);check("Shelly CSV range is 2300",range()==2300);
    put<int32_t>(values+8,16);check("Bull CSV range is 1600",range()==1600);
    put<int32_t>(values+8,27);check("Colt CSV range is 2700",range()==2700);
    put<int32_t>(values+8,33);check("super range independent of primary",range()==3300);
    put<int32_t>(values+8,0x7fffffff);check("missing CSV integer fails closed",range()==0);
    put<int32_t>(values+8,-1);check("negative range rejected",range()==0);
    put<int32_t>(values+8,23);put<int32_t>(row+8,-1);check("negative row rejected",range()==0);put<int32_t>(row+8,2);
    put<int32_t>(0x1243c58,-1);check("uninitialized column rejected",range()==0);put<int32_t>(0x1243c58,3);
    put<uint8_t>(skill+34,1);put(data+0x260,alternate);put<int32_t>(data+516,2);
    put(alternate+8,row+16);put(row+16,table);put<int32_t>(row+24,3);put<int32_t>(values+12,40);
    check("active alternate super range selected",range()==4000);
    put<int32_t>(data+516,1);put<uint8_t>(skill+38,1);
    check("active hyper primary range selected",range()==4000);
    put<uint8_t>(skill+38,0);check("inactive alternate retains base range",range()==2300);
    constexpr uint64_t object=0x9000;put(object+0x10,data);put<int32_t>(data+0x2ac,120);
    int radius=0;check("character collision radius read",bs_metadata::radius(Read{},object,0x2ac,600,radius)&&radius==120);
    put<int32_t>(data+0x130,50);check("projectile radius read",bs_metadata::radius(Read{},object,0x130,850,radius)&&radius==50);
    put<int32_t>(data+0x130,0);check("zero-radius point projectile valid",bs_metadata::radius(Read{},object,0x130,850,radius)&&radius==0);
    put<int32_t>(data+0x130,9000);check("invalid radius rejected",!bs_metadata::radius(Read{},object,0x130,850,radius));
    check("unreadable skill rejected",bs_metadata::casting_range(Read{},0,0xF000)==0);
    std::cout<<"TOTAL "<<passed<<" passed\n";
}
