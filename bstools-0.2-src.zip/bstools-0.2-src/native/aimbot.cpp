#include "game_memory.h"
#include "dobby.h"
#include <jni.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <ctime>
#include <cmath>
#include <array>
#include <algorithm>
#include "aim_signature.h"
#include "dodge_planner.h"
#include "skill_metadata.h"

namespace {
using Activate= int64_t(*)(uint64_t,uint32_t,uint32_t,uint64_t,uint64_t,uint32_t,uint32_t);
using Fire= int64_t(*)(uint64_t,uint64_t,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t);
Activate original=nullptr;
Fire fire=nullptr;
using Sight=int64_t(*)(uint64_t,int32_t,int32_t,int32_t,int32_t);
Sight sight=nullptr;
std::atomic<bool> wall_check{true};
std::atomic<unsigned> wall_rejected{0};
std::atomic<bool> esp_enabled{false};
std::atomic<unsigned> esp_options{63}; // box / HP / line / distance / enemy players only / ammo charge
std::atomic<int> esp_origin{0}; // own character / bottom / top
std::atomic<bool> dodge_enabled{false};
std::atomic<unsigned> dodge_moves{0},incoming_samples{0};
std::atomic<int> dodge_status{0};
std::atomic<unsigned> dodge_cells{0},dodge_threats{0};
std::atomic<int> dodge_before_hits{0},dodge_after_hits{0};
using Allocate=void*(*)(size_t);
using Construct=void(*)(void*,int);
using Queue=void(*)(uint64_t,void*);
using Predict=void(*)(uint64_t,int32_t,int32_t,uint8_t);
Allocate allocate_input=nullptr;Construct construct_input=nullptr;Queue queue_input=nullptr;Predict predict_move=nullptr;
Sight move_sight=nullptr;
struct ProjectileTrack {uint32_t id=0;int32_t x=0,y=0;double vx=0,vy=0;uint64_t tick=0;double radius=450;};
std::array<ProjectileTrack,256> projectile_tracks{};
uint64_t last_dodge_tick=0,next_dodge_move=0,track_battle=0;
uint64_t motion_tick=0;int32_t motion_x=0,motion_y=0;
double motion_vx=0,motion_vy=0,last_evade_x=0,last_evade_y=0;
std::atomic<unsigned> non_player_rejected{0};
std::mutex install_mutex;
std::atomic<bool> enabled{false};
std::atomic<unsigned> calls{0},redirects{0},last_target{0};
std::atomic<bool> installed{false};
uint64_t game_base=0;
std::atomic<bool> metadata_profile_verified{false};
std::atomic<int> last_aim_range{0};
std::atomic<bool> auto_fire{false};
std::atomic<bool> auto_super{false};
std::atomic<unsigned> super_attempts{0},accepted_inputs{0};
std::atomic<bool> super_latched{false};
bool update_installed=false;
std::atomic<unsigned> fire_attempts{0};
std::atomic<unsigned> not_ready{0};
// Captured only on the game thread; discarded when the battle changes.
std::atomic<uint64_t> firing_screen{0},firing_battle{0},firing_own{0};
uint32_t firing_flag=0,firing_id=0;
uint64_t next_fire_ms=0;

uint64_t now_ms() {
    timespec t{}; clock_gettime(CLOCK_MONOTONIC,&t);
    return uint64_t(t.tv_sec)*1000+t.tv_nsec/1000000;
}

bool skill_ready(uint64_t weapon,int expected_type) {
    // 69.230 ECEA4C: normal-attack type 1 requires charge >999.
    // Other skill types and alternate data need separate verified handling.
    uint64_t data=0;int32_t type=0,charge=0,active=0,cooldown=0;
    uint8_t alternate=0,disabled=0,can_continue=0;
    return bstools_read(weapon,data) && data
        && bstools_read(weapon+34,alternate) && alternate==0
        && bstools_read(data+516,type) && type==expected_type
        && bstools_read(weapon+28,charge) && charge>999
        && bstools_read(weapon+16,active) && bstools_read(weapon+24,cooldown)
        && bstools_read(weapon+35,disabled) && disabled==0
        && bstools_read(data+652,can_continue)
        && ((active<1 && cooldown<1) || (can_continue!=0 && active>0));
}

bool player_super_ready(uint64_t battle,uint64_t own) {
    uint64_t array=0,player=0;int32_t count=0,index=0,charge=0,maximum=0;
    if (!bstools_read(battle,array) || !bstools_read(battle+12,count) || count<1 || count>64
        || !bstools_read(own+60,index) || index<0 || index>=count
        || !bstools_read(array+8ULL*index,player) || !player
        || !bstools_read(player+148,charge) || !bstools_read(player+152,maximum)
        || maximum<=0 || charge<0 || charge>maximum) return false;
    // FA8768 checks the player's real Super meter, not the skill's ammo field.
    if (charge<maximum) {super_latched=false;return false;}
    return !super_latched.load();
}

bool object_type(uint64_t object,int expected) {
    uint64_t table=0,fn=0;
    if (!bstools_read(object,table) || !bstools_read(table+0x28,fn)) return false;
    for (int hop=0;hop<3;++hop) {
        uint32_t code[2]{};
        if (!bstools_read(fn,code,sizeof(code))) return false;
        if (code[1]==0xd65f03c0 && (code[0]==(0x52800000u|(uint32_t(expected)<<5))
            || code[0]==(0xd2800000u|(uint32_t(expected)<<5)) || (expected==0 && code[0]==0x2a1f03e0)))
            return true;
        if ((code[0]&0xfc000000)!=0x14000000) return false;
        int32_t displacement=static_cast<int32_t>(code[0]<<6)>>4;
        fn+=displacement;
        if (fn<game_base || fn>=game_base+0x134a000) return false;
    }
    return false;
}
bool character_type(uint64_t object){return object_type(object,0);}

bool player_target(uint64_t battle,uint64_t object) {
    uint64_t players=0,player=0,skills=0;int32_t count=0,index=0,team=0,slots=0;
    if(!bstools_read(battle,players) || !bstools_read(battle+12,count) || count<1 || count>64
        || !bstools_read(object+60,index) || index<0 || index>=count
        || !bstools_read(players+8ULL*index,player) || !player
        || !bstools_read(object+64,team) || team<0 || team>127
        || !bstools_read(object+0xd8,skills) || !bstools_read(object+0xe4,slots) || slots<2 || slots>16)return false;
    bool attack=false,super=false;
    for(int i=0;i<slots;++i){
        uint64_t skill=0,data=0;int32_t type=0;
        if(!bstools_read(skills+8ULL*i,skill) || !skill || !bstools_read(skill,data) || !data || !bstools_read(data+516,type))continue;
        attack|=type==1;super|=type==2;
    }
    return attack && super;
}

double approach_distance_sq(double x,double y,double vx,double vy,double horizon) {
    const double speed=vx*vx+vy*vy;
    const double t=speed>1?std::max(0.0,std::min(horizon,-(x*vx+y*vy)/speed)):0;
    x+=vx*t;y+=vy*t;return x*x+y*y;
}

double trajectory_clearance(double x,double y,double vx,double vy,double mx,double my,double duration,double horizon) {
    const double moving=std::min(duration,horizon);
    double score=approach_distance_sq(x,y,vx-mx,vy-my,moving);
    if(duration<horizon)score=std::min(score,approach_distance_sq(x+(vx-mx)*duration,y+(vy-my)*duration,vx,vy,horizon-duration));
    return score;
}

void run_dodge(uint64_t battle,uint64_t own,uint64_t tick) {
    if (tick-last_dodge_tick<16)return;last_dodge_tick=tick;
    uint64_t manager=0,wrapper=0,input=0,objects=0,array=0,map=0;
    int32_t count=0,team=0,x=0,y=0,width=0,height=0,walk_speed=720;uint8_t hashed=1;
    if (!allocate_input || !construct_input || !queue_input || !predict_move || !move_sight
        || !bstools_read(game_base+0x1306e50,manager) || !bstools_read(manager+0x48,wrapper)
        || !bstools_read(wrapper+112,hashed) || !bstools_read(wrapper+88,input) || !input
        || !bstools_read(own+0x40,team) || !bstools_read(own+0x30,x) || !bstools_read(own+0x34,y)
        || !bstools_read(battle+0xf8,map) || !map || !bstools_read(map+0xc4,width) || !bstools_read(map+0xc8,height)
        || width<1 || width>120 || height<1 || height>120
        || !bstools_read(battle+0x28,objects) || !bstools_read(objects,array)
        || !bstools_read(objects+12,count) || count<0 || count>512)return;
    if(hashed!=0){dodge_status=2;dodge_enabled=false;return;}
    dodge_status=1;
    if(track_battle!=battle){projectile_tracks={};track_battle=battle;next_dodge_move=0;motion_tick=0;motion_vx=motion_vy=last_evade_x=last_evade_y=0;}
    bstools_read(own+588,walk_speed);if(walk_speed<100 || walk_speed>3000)walk_speed=720;
    if(motion_tick && tick>motion_tick && tick-motion_tick<300){
        double dt=(tick-motion_tick)*.001,vx=(x-motion_x)/dt,vy=(y-motion_y)/dt;
        if(vx*vx+vy*vy<walk_speed*walk_speed*2.25){motion_vx=.65*vx+.35*motion_vx;motion_vy=.65*vy+.35*motion_vy;}
        else motion_vx=motion_vy=0;
    }
    else motion_vx=motion_vy=0;
    motion_x=x;motion_y=y;motion_tick=tick;
    auto read=[](uint64_t address,auto& value){return bstools_read(address,value);};
    int own_radius=120;
    const bool own_radius_known=metadata_profile_verified && bs_metadata::radius(read,own,0x2ac,600,own_radius) && own_radius>=20;
    for(int i=0;i<count;++i) {
        uint64_t object=0;uint32_t id=0;int32_t other=0,px=0,py=0;
        if(!bstools_read(array+8ULL*i,object) || !object || !object_type(object,1)
            || !bstools_read(object+0x40,other) || other==team || other< -1 || other>127
            || !bstools_read(object+8,id) || !id || !bstools_read(object+0x30,px) || !bstools_read(object+0x34,py)
            || px<0 || py<0 || px>=width*300 || py>=height*300)continue;
        // Open addressing avoids losing both tracks when IDs share id % 256.
        ProjectileTrack* slot=nullptr;
        for(size_t probe=0;probe<projectile_tracks.size();++probe){
            auto& entry=projectile_tracks[(id+probe)%projectile_tracks.size()];
            if(entry.id==id){slot=&entry;break;}
            if(!slot && (!entry.tick || tick-entry.tick>300))slot=&entry;
        }
        if(!slot)continue;
        auto& old=*slot;
        int bullet_radius=0;
        const double combined=own_radius_known && bs_metadata::radius(read,object,0x130,850,bullet_radius)
            ?own_radius+bullet_radius+45.0:450.0;
        if(old.id!=id || !old.tick || tick-old.tick>300){old={id,px,py,0,0,tick,combined};continue;}
        const double dt=(tick-old.tick)*0.001;
        if(dt<.008)continue;
        double vx=(px-old.x)/dt,vy=(py-old.y)/dt;
        const double speed=vx*vx+vy*vy;
        if(speed<10000 || speed>900000000){old={id,px,py,0,0,tick,combined};continue;}
        if(old.vx || old.vy){vx=.6*vx+.4*old.vx;vy=.6*vy+.4*old.vy;}
        old={id,px,py,vx,vy,tick,combined};++incoming_samples;
    }
    using namespace bstools_dodge;
    std::array<Threat,32> threats{};std::array<double,32> priorities{};
    std::array<Enemy,8> enemies{};
    size_t threat_count=0,enemy_count=0;
    for(const auto& p:projectile_tracks){
        if(!p.tick || tick-p.tick>150 || (!p.vx && !p.vy))continue;
        const double age=(tick-p.tick)*.001;
        const Vec relative{p.x+p.vx*age-x,p.y+p.vy*age-y};
        const double risk=std::min(approach_distance_sq(relative.x,relative.y,p.vx,p.vy,.9),
            approach_distance_sq(relative.x,relative.y,p.vx-motion_vx,p.vy-motion_vy,.9));
        if(risk>1250.0*1250.0 && dot(relative,relative)>2500.0*2500.0)continue;
        size_t at=threat_count;
        if(at==threats.size()){
            at=std::max_element(priorities.begin(),priorities.end())-priorities.begin();
            if(risk>=priorities[at])continue;
        }else ++threat_count;
        threats[at]={relative,{p.vx,p.vy},p.radius};priorities[at]=risk;
    }
    dodge_threats=static_cast<unsigned>(threat_count);
    dodge_cells=0;
    if(!threat_count || tick<next_dodge_move)return;
    for(int i=0;i<count && enemy_count<enemies.size();++i){
        uint64_t object=0;int32_t other=0,px=0,py=0,hp=0;
        if(!bstools_read(array+8ULL*i,object) || !object || object==own || !character_type(object)
            || !bstools_read(object+64,other) || other==team || !player_target(battle,object)
            || !bstools_read(object+0xc4,hp) || hp<=0
            || !bstools_read(object+0x30,px) || !bstools_read(object+0x34,py))continue;
        enemies[enemy_count++]={{double(px-x),double(py-y)}};
    }
    auto clear=[&](Vec delta){
        const int32_t cx=x+int32_t(std::lround(delta.x)),cy=y+int32_t(std::lround(delta.y));
        if(cx<200 || cy<200 || cx>=width*300-200 || cy>=height*300-200)return false;
        const double distance=length(delta);
        if(distance<1)return true;
        const int32_t sx=int32_t(-delta.y/distance*180),sy=int32_t(delta.x/distance*180);
        return (move_sight(map,x,y,cx,cy)&1)
            && (move_sight(map,x+sx,y+sy,cx+sx,cy+sy)&1)
            && (move_sight(map,x-sx,y-sy,cx-sx,cy-sy)&1);
    };
    const auto plan=solve(threats,threat_count,enemies,enemy_count,{motion_vx,motion_vy},walk_speed,
        {last_evade_x-x,last_evade_y-y},next_dodge_move && tick<next_dodge_move+220,clear);
    dodge_cells=plan.cells;dodge_before_hits=plan.before.intrusions;dodge_after_hits=plan.after.intrusions;
    if(!plan.modified)return;
    if(length(plan.destination)<1 && std::hypot(motion_vx,motion_vy)<20)return;
    const int32_t tx=x+int32_t(std::lround(plan.destination.x)),ty=y+int32_t(std::lround(plan.destination.y));
    void* command=allocate_input(72);if(!command)return;
    std::memset(command,0,72);construct_input(command,2);
    std::memcpy(static_cast<char*>(command)+12,&tx,sizeof(tx));std::memcpy(static_cast<char*>(command)+16,&ty,sizeof(ty));
    predict_move(battle,tx,ty,1);queue_input(input,command);++dodge_moves;
    last_evade_x=tx;last_evade_y=ty;next_dodge_move=tick+60;
}

bool select_target(uint64_t own,uint64_t skill,int32_t& tx,int32_t& ty,uint32_t& target_id,bool check_walls=true) {
    int32_t slots=0,own_team=0,ox=0,oy=0;
    uint64_t skills=0,weapon=0;
    if (!bstools_read(own+0xe4,slots) || slots<1 || slots>16
        || !bstools_read(own+0xd8,skills) || !bstools_read(skills,weapon)
        || !bstools_read(own+0x40,own_team) || own_team<0 || own_team>127
        || !bstools_read(own+0x30,ox) || !bstools_read(own+0x34,oy)) return false;
    if (weapon!=skill) {
        bool own_super=false;
        for(int i=0;i<slots;++i) {
            uint64_t candidate=0,data=0;int32_t type=0;
            if (bstools_read(skills+8ULL*i,candidate) && candidate==skill
                && bstools_read(candidate,data) && bstools_read(data+516,type) && type==2) {own_super=true;break;}
        }
        if(!own_super)return false;
    }
    uint64_t manager=0,screen=0,battle=0,objects=0,array=0;
    int32_t screen_type=0,count=0;
    if (!bstools_read(game_base+0x1306e50,manager) || !bstools_read(manager+0x50,screen_type) || screen_type!=5
        || !bstools_read(manager+0x48,screen) || !bstools_read(screen+0x28,battle)
        || !bstools_read(battle+0x28,objects) || !bstools_read(objects+0xc,count)
        || count<0 || count>2000 || !bstools_read(objects,array)) return false;
    if(!metadata_profile_verified)return false;
    const int range=bs_metadata::casting_range([](uint64_t address,auto& value){return bstools_read(address,value);},game_base,skill);
    last_aim_range=range;
    if(range<=0)return false;
    int64_t best_distance=int64_t(range)*range;
    bool found=false;
    uint64_t tile_map=0;int32_t width=0,height=0;
    if (check_walls && wall_check.load()) {
        if (!sight || !bstools_read(battle+0xf8,tile_map) || !tile_map
            || !bstools_read(tile_map+0xc4,width) || !bstools_read(tile_map+0xc8,height)
            || width<1 || width>120 || height<1 || height>120
            || ox<0 || oy<0 || ox>=width*300 || oy>=height*300) return false;
    }
    for (int i=0;i<count;++i) {
        uint64_t object=0;int32_t team=0,hp=0,max_hp=0,x=0,y=0;uint32_t id=0;
        if (!bstools_read(array+8ULL*i,object) || !object || object==own || !character_type(object)
            || !bstools_read(object+0x40,team) || team==own_team || team<0 || team>127
            || !bstools_read(object+0xc4,hp) || !bstools_read(object+0xc8,max_hp)
            || hp<1 || max_hp<hp || max_hp>1000000
            || !bstools_read(object+8,id) || !bstools_read(object+0x30,x) || !bstools_read(object+0x34,y)
            || x<0 || y<0 || x>1000000 || y>1000000) continue;
        if(!player_target(battle,object)){++non_player_rejected;continue;}
        int64_t dx=static_cast<int64_t>(x)-ox,dy=static_cast<int64_t>(y)-oy;
        int64_t distance=dx*dx+dy*dy;
        if (distance>best_distance || (found && distance==best_distance)) continue;
        if (check_walls && wall_check.load()) {
            if (x>=width*300 || y>=height*300 || !(sight(tile_map,ox,oy,x,y)&1)) {++wall_rejected;continue;}
        }
        found=true;best_distance=distance;tx=x;ty=y;target_id=id;
    }
    return found;
}

int64_t redirect(uint64_t screen,uint32_t x,uint32_t y,uint64_t own,uint64_t skill,uint32_t flag,uint32_t id) {
    ++calls;
    uint64_t wrapper=0,battle=0,skills=0,primary=0;
    if (bstools_read(screen+0x918,wrapper) && bstools_read(wrapper+0x28,battle)
        && bstools_read(own+0xd8,skills) && bstools_read(skills,primary) && primary==skill) {
        if (firing_battle!=battle || firing_own!=own) super_latched=false;
        firing_screen=screen;firing_battle=battle;firing_own=own;firing_flag=flag;firing_id=id;
    }
    if (enabled.load(std::memory_order_acquire)) {
        int32_t tx=0,ty=0;uint32_t target=0;
        if (select_target(own,skill,tx,ty,target)) {
            x=static_cast<uint32_t>(tx);y=static_cast<uint32_t>(ty);
            if(flag&1)id=target;
            last_target=target;++redirects;
        } else if(flag&1) {
            last_target=0;
            return 0;
        }
    }
    return original ? original(screen,x,y,own,skill,flag,id) : 0;
}

void battle_tick(void*,DobbyRegisterContext* context) {
    if (!auto_fire.load(std::memory_order_acquire) && !auto_super.load(std::memory_order_acquire) && !dodge_enabled.load()) return;
    const uint64_t battle=context->general.regs.x0;
    if (!firing_screen || battle!=firing_battle) return;
    const uint64_t tick=now_ms();
    uint64_t wrapper=0,current=0,skills=0,weapon=0;
    uint32_t own_id=0,expected=0;int32_t health=0;
    if (!bstools_read(firing_screen+0x918,wrapper) || !bstools_read(wrapper+0x28,current) || current!=battle
        || !bstools_read(battle+0x100,expected) || !bstools_read(firing_own+8,own_id) || own_id!=expected
        || !bstools_read(firing_own+0xc4,health) || health<=0
        || !bstools_read(firing_own+0xd8,skills) || !bstools_read(skills,weapon)) return;
    if(dodge_enabled.load())run_dodge(battle,firing_own.load(),tick);
    if(!fire || (!auto_fire.load() && !auto_super.load()) || tick<next_fire_ms)return;
    next_fire_ms=tick+250;
    int32_t x=0,y=0;uint32_t target=0;
    if (auto_super.load() && player_super_ready(battle,firing_own)) {
        int32_t count=0;
        if (bstools_read(firing_own+0xe4,count) && count>0 && count<=16) {
            for (int i=0;i<count;++i) {
                uint64_t candidate=0;
                if (!bstools_read(skills+8ULL*i,candidate) || !skill_ready(candidate,2)
                    || !select_target(firing_own,candidate,x,y,target)) continue;
                ++super_attempts;
                if (fire(firing_screen,firing_own,candidate,uint32_t(x),uint32_t(y),0,0)&1) {
                    super_latched=true;++accepted_inputs;return;
                }
                break;
            }
        }
    }
    if (!auto_fire.load()) return;
    if (!select_target(firing_own,weapon,x,y,target)) return;
    if (!skill_ready(weapon,1)) {++not_ready;return;}
    // JS activation ABI: screen, character, skill, X, Y, flag, target.
    ++fire_attempts;
    if (fire(firing_screen,firing_own,weapon,uint32_t(x),uint32_t(y),0,0)&1) ++accepted_inputs;
}

jstring state(JNIEnv* env,const char* status) {
    char json[512];snprintf(json,sizeof(json),
        "{\"enabled\":%s,\"installed\":%s,\"calls\":%u,\"redirects\":%u,\"target\":%u,\"status\":\"%s\"}",
        enabled.load()?"true":"false",installed?"true":"false",calls.load(),redirects.load(),last_target.load(),status);
    return env->NewStringUTF(json);
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setAimEnabled(JNIEnv* env,jclass,jboolean value) {
    std::lock_guard<std::mutex> lock(install_mutex);
    if (!value) { enabled=false; auto_fire=false; auto_super=false; last_target=0; return state(env,"Kapali"); }
    if (!installed) {
        game_base=bstools_module_base();
        unsigned char actual[sizeof(kAimSignature)]{};
        if (!game_base || !bstools_read(game_base+0xb2d678,actual,sizeof(actual))
            || memcmp(actual,kAimSignature,sizeof(actual))) return state(env,"Surum uyusmuyor");
        unsigned char sight_code[sizeof(kSightSignature)]{};
        if (!bstools_read(game_base+0xd993f4,sight_code,sizeof(sight_code))
            || memcmp(sight_code,kSightSignature,sizeof(sight_code))) return state(env,"Duvar kontrolu surum uyusmazligi");
        sight=reinterpret_cast<Sight>(game_base+0xd993f4);
        auto matches=[&](uint64_t offset,const auto& expected){
            unsigned char bytes[sizeof(expected)]{};
            return bstools_read(game_base+offset,bytes,sizeof(bytes)) && !std::memcmp(bytes,expected,sizeof(bytes));
        };
        if(!matches(0xe57a08,kRangeReaderSignature) || !matches(0x5324f4,kCsvIntSignature)
            || !matches(0xeb0cc0,kObjectDataSignature) || !matches(0xe44a10,kProjectileRadiusSignature)
            || !matches(0xdf14d8,kCharacterRadiusStoreSignature))return state(env,"Menzil verisi surum uyusmazligi");
        metadata_profile_verified=true;
        if (DobbyHook(reinterpret_cast<void*>(game_base+0xb2d678),reinterpret_cast<void*>(redirect),
                      reinterpret_cast<void**>(&original))!=0 || !original) return state(env,"Aimbot baglanamadi");
        installed=true;
    }
    enabled=true;return state(env,"Acik");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_disableAll(JNIEnv* env,jclass) {
    std::lock_guard<std::mutex> lock(install_mutex);
    enabled=false;auto_fire=false;auto_super=false;esp_enabled=false;dodge_enabled=false;last_target=0;
    return state(env,"Kapali");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_aimState(JNIEnv* env,jclass) { return state(env,enabled?"Acik":"Kapali"); }

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_autoFireState(JNIEnv* env,jclass) {
    char json[1024];snprintf(json,sizeof(json),
        "{\"enabled\":%s,\"attempts\":%u,\"superEnabled\":%s,\"superAttempts\":%u,\"acceptedInputs\":%u,\"notReady\":%u,\"wallCheck\":%s,\"wallRejected\":%u,\"dodgeEnabled\":%s,\"dodgeMoves\":%u,\"incomingSamples\":%u,\"dodgeStatus\":%d,\"dodgePlanner\":\"refuge-v7plus\",\"dodgeCells\":%u,\"dodgeThreats\":%u,\"dodgeBeforeHits\":%d,\"dodgeAfterHits\":%d,\"status\":\"%s\"}",
        auto_fire.load()?"true":"false",fire_attempts.load(),auto_super.load()?"true":"false",super_attempts.load(),accepted_inputs.load(),not_ready.load(),wall_check.load()?"true":"false",wall_rejected.load(),dodge_enabled.load()?"true":"false",dodge_moves.load(),incoming_samples.load(),dodge_status.load(),
        dodge_cells.load(),dodge_threats.load(),dodge_before_hits.load(),dodge_after_hits.load(),
        auto_fire.load()?"Her savasta once bir normal atis yap":"Kapali");
    return env->NewStringUTF(json);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setWallCheckEnabled(JNIEnv* env,jclass type,jboolean value) {
    wall_check=value;
    return Java_com_local_bstools_MenuBridge_autoFireState(env,type);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setAutoFireEnabled(JNIEnv* env,jclass type,jboolean value) {
    if (!value) {auto_fire=false;return Java_com_local_bstools_MenuBridge_autoFireState(env,type);}
    Java_com_local_bstools_MenuBridge_setAimEnabled(env,type,JNI_TRUE);
    std::lock_guard<std::mutex> lock(install_mutex);
    if (!installed) return state(env,"Once aimbot baglantisi gerekli");
    unsigned char fire_code[sizeof(kFireSignature)]{};
    if (!bstools_read(game_base+0xb3c544,fire_code,sizeof(fire_code))
        || memcmp(fire_code,kFireSignature,sizeof(fire_code))) return state(env,"Ates fonksiyonu surum uyusmazligi");
    fire=reinterpret_cast<Fire>(game_base+0xb3c544);
    if (!update_installed) {
        unsigned char actual[sizeof(kUpdateSignature)]{};
        if (!bstools_read(game_base+0xf83fd8,actual,sizeof(actual))
            || memcmp(actual,kUpdateSignature,sizeof(actual))
            || DobbyInstrument(reinterpret_cast<void*>(game_base+0xf83fd8),battle_tick)!=0)
            return state(env,"Otomatik ates baglanamadi");
        update_installed=true;
    }
    auto_fire=true;
    return Java_com_local_bstools_MenuBridge_autoFireState(env,type);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setAutoSuperEnabled(JNIEnv* env,jclass type,jboolean value) {
    if (!value) {auto_super=false;super_latched=false;return Java_com_local_bstools_MenuBridge_autoFireState(env,type);}
    const bool previous=auto_fire.load();
    jstring result=Java_com_local_bstools_MenuBridge_setAutoFireEnabled(env,type,JNI_TRUE);
    auto_fire=previous;
    super_latched=false;
    auto_super=update_installed && fire!=nullptr;
    env->DeleteLocalRef(result);
    return Java_com_local_bstools_MenuBridge_autoFireState(env,type);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setDodgeEnabled(JNIEnv* env,jclass type,jboolean value) {
    if(!value){dodge_enabled=false;dodge_status=0;return Java_com_local_bstools_MenuBridge_autoFireState(env,type);}
    const bool previous_aim=enabled.load(),previous_fire=auto_fire.load();
    jstring setup=Java_com_local_bstools_MenuBridge_setAutoFireEnabled(env,type,JNI_TRUE);
    enabled=previous_aim;auto_fire=previous_fire;env->DeleteLocalRef(setup);
    if(!update_installed || !original)return state(env,"Dodge oyun dongusune baglanamadi");
    auto matches=[&](uint64_t offset,const auto& expected){
        unsigned char actual[sizeof(expected)]{};
        return bstools_read(game_base+offset,actual,sizeof(actual)) && !std::memcmp(actual,expected,sizeof(actual));
    };
    if(!matches(0x11a1900,kAllocateSignature) || !matches(0xf4752c,kConstructSignature)
        || !matches(0xaa173c,kQueueSignature) || !matches(0xf860a0,kPredictSignature)
        || !matches(0xd99394,kMoveSightSignature))return state(env,"Dodge hareketi surum uyusmazligi");
    allocate_input=reinterpret_cast<Allocate>(game_base+0x11a1900);
    construct_input=reinterpret_cast<Construct>(game_base+0xf4752c);
    queue_input=reinterpret_cast<Queue>(game_base+0xaa173c);
    predict_move=reinterpret_cast<Predict>(game_base+0xf860a0);
    move_sight=reinterpret_cast<Sight>(game_base+0xd99394);
    dodge_status=0;dodge_enabled=true;
    return Java_com_local_bstools_MenuBridge_autoFireState(env,type);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_dodgePlannerCheck(JNIEnv* env,jclass) {
    const double incoming=approach_distance_sq(1000,0,-1000,0,.65);
    const double outgoing=approach_distance_sq(1000,0,1000,0,.65);
    const double evading=approach_distance_sq(1000,0,-1000,-720,.65);
    const double early_stop=trajectory_clearance(1000,0,-1000,0,0,1000,.1,1);
    const double continuing=trajectory_clearance(1000,0,-1000,0,0,1000,1,1);
    const double escaping=approach_distance_sq(1000,0,-1000,-1500,.8);
    char json[512];snprintf(json,sizeof(json),"{\"incomingDanger\":%s,\"outgoingSafe\":%s,\"lateralSafer\":%s,\"earlyStopLessSafe\":%s,\"existingEscapeRecognized\":%s,\"movementSent\":false}",
        incoming<450*450?"true":"false",outgoing>450*450?"true":"false",evading>incoming?"true":"false",
        early_stop<continuing?"true":"false",escaping>450*450?"true":"false");
    return env->NewStringUTF(json);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_targetFilterCheck(JNIEnv* env,jclass) {
    alignas(8) unsigned char battle[64]{},object[256]{},player[16]{},attack[8]{},super[8]{},attack_data[528]{},super_data[528]{};
    uint64_t players[]={reinterpret_cast<uint64_t>(player)},skills[]={reinterpret_cast<uint64_t>(attack),reinterpret_cast<uint64_t>(super)};
    auto put=[](void* base,size_t off,const auto& value){std::memcpy(static_cast<char*>(base)+off,&value,sizeof(value));};
    uint64_t roster=reinterpret_cast<uint64_t>(players),skill_list=reinterpret_cast<uint64_t>(skills);
    uint64_t ad=reinterpret_cast<uint64_t>(attack_data),sd=reinterpret_cast<uint64_t>(super_data);
    int32_t one=1,two=2,zero=0,negative=-1,invalid=3;
    put(battle,0,roster);put(battle,12,one);put(object,60,zero);put(object,64,one);
    put(object,0xd8,skill_list);put(object,0xe4,two);put(attack,0,ad);put(super,0,sd);
    put(attack_data,516,one);put(super_data,516,two);
    const uint64_t b=reinterpret_cast<uint64_t>(battle),o=reinterpret_cast<uint64_t>(object);
    bool hero=player_target(b,o);
    put(object,60,negative);bool npc=!player_target(b,o);
    put(object,60,invalid);bool invalid_index=!player_target(b,o);
    put(object,60,zero);put(object,64,negative);bool neutral=!player_target(b,o);
    put(object,64,one);put(object,0xe4,one);bool single_skill=!player_target(b,o);
    char json[384];snprintf(json,sizeof(json),"{\"playerAccepted\":%s,\"unownedNpcRejected\":%s,\"invalidIndexRejected\":%s,\"neutralRejected\":%s,\"singleSkillRejected\":%s,\"gameMemoryWrites\":false}",
        hero?"true":"false",npc?"true":"false",invalid_index?"true":"false",neutral?"true":"false",single_skill?"true":"false");
    return env->NewStringUTF(json);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setEspEnabled(JNIEnv* env,jclass type,jboolean value) {
    if (!value) {esp_enabled=false;return env->NewStringUTF("{\"enabled\":false}");}
    const bool previous=enabled.load();
    jstring setup=Java_com_local_bstools_MenuBridge_setAimEnabled(env,type,JNI_TRUE);
    enabled=previous;env->DeleteLocalRef(setup);
    esp_enabled=installed.load();
    return env->NewStringUTF(esp_enabled?"{\"enabled\":true}":"{\"enabled\":false,\"status\":\"Baglanti kurulamadi\"}");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_setEspOptions(JNIEnv* env,jclass,jint flags,jint origin) {
    esp_options=static_cast<unsigned>(flags)&63u;esp_origin=std::clamp(int(origin),0,2);
    char json[128];snprintf(json,sizeof(json),"{\"flags\":%u,\"origin\":%d}",esp_options.load(),esp_origin.load());
    return env->NewStringUTF(json);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_espSnapshot(JNIEnv* env,jclass) {
    if (!esp_enabled.load()) return env->NewStringUTF("{\"enabled\":false,\"boxes\":[]}");
    uint64_t manager=0,wrapper=0,battle=0,objects=0,array=0;
    const uint64_t screen=firing_screen.load(),own=firing_own.load();
    int32_t type=0,count=0,team=0,ox=0,oy=0,oz=0;uint32_t own_id=0,expected_id=0;float m[16]{},width=0,height=0;
    if (!screen || !own || !bstools_read(game_base+0x1306e50,manager)
        || !bstools_read(manager+0x50,type) || type!=5
        || !bstools_read(manager+0x48,wrapper) || !bstools_read(wrapper+0x28,battle)
        || battle!=firing_battle.load() || !bstools_read(battle+0x100,expected_id)
        || !bstools_read(own+8,own_id) || own_id!=expected_id || !bstools_read(own+0x40,team)
        || !bstools_read(own+0x30,ox) || !bstools_read(own+0x34,oy) || !bstools_read(own+0x38,oz)
        || !bstools_read(screen+0x868,m,sizeof(m)) || !bstools_read(screen+0x904,width)
        || !bstools_read(screen+0x908,height) || !std::isfinite(width) || !std::isfinite(height)
        || width<128 || height<128 || width>8192 || height>8192
        || !bstools_read(battle+0x28,objects) || !bstools_read(objects,array)
        || !bstools_read(objects+12,count) || count<0 || count>2000)
        return env->NewStringUTF("{\"enabled\":true,\"status\":\"Savasta once bir normal atis yap\",\"boxes\":[]}");
    for(float value:m)if(!std::isfinite(value))return env->NewStringUTF("{\"enabled\":true,\"boxes\":[]}");
    auto project=[&](float x,float y,float z,float& sx,float& sy) {
        y=-y;const float w=m[3]*x+m[7]*y+m[11]*z+m[15];
        if (!std::isfinite(w) || w<=0.0001f)return false;
        sx=0.5f+0.5f*(m[0]*x+m[4]*y+m[8]*z+m[12])/w;
        sy=0.5f-0.5f*(m[1]*x+m[5]*y+m[9]*z+m[13])/w;
        return std::isfinite(sx)&&std::isfinite(sy)&&sx> -1 && sx<2 && sy> -1 && sy<2;
    };
    const unsigned flags=esp_options.load();const int origin=esp_origin.load();
    float anchor_x=.5f,anchor_y=origin==2?.06f:.96f;
    if(origin==0){float sx=0,sy=0;if(project(ox,oy,oz,sx,sy)){anchor_x=sx;anchor_y=sy;}}
    char json[24576];size_t used=snprintf(json,sizeof(json),
        "{\"enabled\":true,\"flags\":%u,\"origin\":%d,\"anchorX\":%.5f,\"anchorY\":%.5f,\"boxes\":[",flags,origin,anchor_x,anchor_y);int drawn=0;
    for(int i=0;i<count && drawn<64;++i) {
        uint64_t object=0;int32_t other_team=0,x=0,y=0,z=0,hp=0,maximum=0;
        if (!bstools_read(array+8ULL*i,object) || !object || object==own || !character_type(object)
            || !bstools_read(object+0x40,other_team) || other_team< -1 || other_team==team || other_team>127
            || !bstools_read(object+0x30,x) || !bstools_read(object+0x34,y) || !bstools_read(object+0x38,z)
            || !bstools_read(object+0xc4,hp) || !bstools_read(object+0xc8,maximum)
            || hp<=0 || maximum<hp || maximum>1000000 || z< -1000 || z>10000)continue;
        const bool enemy=other_team>=0 && player_target(battle,object);
        if((flags&16) && !enemy)continue;
        float left=0,bottom=0,right=0,bottom2=0,middle=0,top=0;
        if (!project(x-150.f,y,z,left,bottom) || !project(x+150.f,y,z,right,bottom2)
            || !project(x,y,z+500.f,middle,top) || right<=left || bottom<=top)continue;
        float foot_x=0,foot_y=0;if(!project(x,y,z,foot_x,foot_y))continue;
        const double distance=std::hypot(double(x)-ox,double(y)-oy)/300.0;
        double ammo=-1;
        if((flags&32) && enemy){
            uint64_t skills=0;int32_t slots=0;
            if(bstools_read(object+0xd8,skills) && bstools_read(object+0xe4,slots) && slots>=1 && slots<=16)
                for(int k=0;k<slots;++k){
                    uint64_t skill=0,data=0;int32_t kind=0,charge=0;uint8_t alternate=1;
                    if(bstools_read(skills+8ULL*k,skill) && skill && bstools_read(skill,data) && data
                        && bstools_read(data+516,kind) && kind==1 && bstools_read(skill+34,alternate) && !alternate
                        && bstools_read(skill+28,charge) && charge>=0 && charge<=20000){ammo=charge/1000.0;break;}
                }
        }
        int written=snprintf(json+used,sizeof(json)-used,
            "%s{\"l\":%.5f,\"t\":%.5f,\"r\":%.5f,\"b\":%.5f,\"fx\":%.5f,\"fy\":%.5f,\"hp\":%d,\"max\":%d,\"distanceTiles\":%.2f,\"ammoCharge\":%.2f,\"enemy\":%s}",
            drawn?",":"",left,top,right,bottom,foot_x,foot_y,hp,maximum,distance,ammo,enemy?"true":"false");
        if(written<0 || size_t(written)>=sizeof(json)-used-4)break;
        used+=written;++drawn;
    }
    snprintf(json+used,sizeof(json)-used,"]}");return env->NewStringUTF(json);
}

// Developer validation: exercise the exact selector without installing a hook.
extern "C" JNIEXPORT jstring JNICALL
Java_com_local_bstools_MenuBridge_previewAim(JNIEnv* env,jclass) {
    std::lock_guard<std::mutex> lock(install_mutex);
    if (!game_base) game_base=bstools_module_base();
    uint64_t manager=0,screen=0,battle=0,objects=0,array=0,own=0,skills=0,weapon=0;
    int32_t type=0,count=0;uint32_t own_id=0;
    if (!game_base || !bstools_read(game_base+0x1306e50,manager) || !bstools_read(manager+0x50,type) || type!=5
        || !bstools_read(manager+0x48,screen) || !bstools_read(screen+0x28,battle)
        || !bstools_read(battle+0x28,objects) || !bstools_read(objects+0xc,count)
        || count<0 || count>2000 || !bstools_read(objects,array) || !bstools_read(battle+0x100,own_id))
        return state(env,"Karakter bekleniyor");
    for (int i=0;i<count;++i) {
        uint64_t p=0;uint32_t id=0;
        if (bstools_read(array+8ULL*i,p) && bstools_read(p+8,id) && id==own_id) {own=p;break;}
    }
    if (!own || !bstools_read(own+0xd8,skills) || !bstools_read(skills,weapon))
        return state(env,"Silah bekleniyor");
    int32_t x=0,y=0;uint32_t id=0;
    bool found=select_target(own,weapon,x,y,id,false);
    char json[256];snprintf(json,sizeof(json),"{\"found\":%s,\"x\":%d,\"y\":%d,\"target\":%u,\"gameCodePatched\":false}",
        found?"true":"false",x,y,id);
    return env->NewStringUTF(json);
}
