#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <limits>

// Portable collision planner. No game addresses or movement injection here.
namespace bstools_dodge {
struct Vec { double x=0,y=0; };
inline Vec operator+(Vec a,Vec b){return {a.x+b.x,a.y+b.y};}
inline Vec operator-(Vec a,Vec b){return {a.x-b.x,a.y-b.y};}
inline Vec operator*(Vec a,double n){return {a.x*n,a.y*n};}
inline double dot(Vec a,Vec b){return a.x*b.x+a.y*b.y;}
inline double length(Vec a){return std::hypot(a.x,a.y);}
struct Threat { Vec position,velocity; double radius=450; };
struct Enemy { Vec position; };
struct Path {
    Vec velocity,destination;double arrival=0;
    Vec initial_velocity{};double delay=0;
    Vec at(double t)const{
        if(t<delay)return initial_velocity*t;
        return t<arrival?initial_velocity*delay+velocity*(t-delay):destination;
    }
};
struct Score {int intrusions=0;double field=0,clearance=1e9;};
struct Result {bool modified=false;Vec destination;Score before,after;unsigned cells=0;};
inline Path toward(Vec destination,double speed,Vec initial_velocity={},double delay=0){
    const Vec remaining=destination-initial_velocity*delay;
    const double distance=length(remaining);
    return {distance>1e-6?remaining*(speed/distance):Vec{},destination,delay+distance/std::max(1.0,speed),initial_velocity,delay};
}
inline double closest(Vec relative,Vec velocity,double start,double end){
    const double speed=dot(velocity,velocity);
    const double t=speed>1e-9?std::clamp(-dot(relative,velocity)/speed,start,end):start;
    return length(relative+velocity*t);
}
inline double clearance(const Threat& threat,const Path& path,double horizon){
    double minimum=1e9;
    if(path.delay>0)minimum=closest(threat.position,threat.velocity-path.initial_velocity,0,std::min(path.delay,horizon));
    const double arrival=std::min(path.arrival,horizon);
    if(arrival>path.delay)minimum=std::min(minimum,
        closest(threat.position-path.initial_velocity*path.delay+path.velocity*path.delay,
            threat.velocity-path.velocity,path.delay,arrival));
    if(path.arrival<horizon)minimum=std::min(minimum,
        closest(threat.position-path.destination,threat.velocity,path.arrival,horizon));
    return minimum-threat.radius;
}
template<size_t N,size_t E>
Score evaluate(const std::array<Threat,N>& threats,size_t count,
               const std::array<Enemy,E>& enemies,size_t enemy_count,const Path& path,double horizon){
    Score score;
    for(size_t i=0;i<count;++i){
        const auto& p=threats[i];const double gap=clearance(p,path,horizon);
        score.clearance=std::min(score.clearance,gap);
        if(gap<0){++score.intrusions;score.field+=1e6-gap*1500;}
        else if(gap<100)score.field+=(100-gap)*18;
        // Distinguish escape paths even when every path overlaps at t=0.
        for(double fraction:{.1,.2,.35,.5,.75,1.}){
            const double t=fraction*horizon;
            const double penetration=p.radius-length(p.position+p.velocity*t-path.at(t));
            if(penetration>0)score.field+=penetration*300;
        }
    }
    const Vec endpoint=path.at(horizon);
    for(size_t i=0;i<enemy_count;++i){
        const double distance=length(enemies[i].position-endpoint);
        if(distance<1500)score.field+=(1500-distance)*1.2;
        if(distance<80){++score.intrusions;score.field+=(80-distance)*200;}
    }
    return score;
}
inline bool better(const Score& a,const Score& b){
    return a.intrusions<b.intrusions || (a.intrusions==b.intrusions && a.field<b.field-1e-6);
}
template<size_t N,size_t E,class Clear>
Result solve(const std::array<Threat,N>& threats,size_t count,
             const std::array<Enemy,E>& enemies,size_t enemy_count,Vec current_velocity,
             double speed,Vec previous_refuge,bool recent,Clear clear){
    constexpr double horizon=.9;
    Result result;if(!count)return result;
    const Path baseline{current_velocity,current_velocity*horizon,horizon};
    result.before=evaluate(threats,count,enemies,enemy_count,baseline,horizon);
    result.after=result.before;
    // Preserve an existing safe movement, even if steering somewhere else
    // would marginally reduce enemy-pressure or distance costs.
    if(result.before.intrusions==0 && result.before.clearance>=50)return result;
    auto consider=[&](Vec destination){
        if(!clear(destination))return;
        ++result.cells;
        const Path path=toward(destination,speed,current_velocity,.06);
        Score score=evaluate(threats,count,enemies,enemy_count,path,horizon);
        score.field+=length(destination)*.05;
        if(recent){const double cluster=length(destination-previous_refuge);
            if(cluster<90)score.field-=(90-cluster)*(70.0/90);}
        const double movement=length(current_velocity),distance=length(destination);
        if(movement>100 && distance>1)
            score.field+=std::max(0.0,1-dot(current_velocity,destination)/(movement*distance))*70;
        if(better(score,result.after)){
            result.after=score;result.destination=destination;result.modified=true;
        }
    };
    consider({});
    const double radii[]={60,130,220,350,500,600,850};
    const int counts[]={8,12,16,12,8,32,32};
    for(int ring=0;ring<7;++ring)for(int i=0;i<counts[ring];++i){
        const double angle=i*6.283185307179586/counts[ring];
        consider({radii[ring]*std::cos(angle),radii[ring]*std::sin(angle)});
    }
    // Near-miss-only changes need a useful gain to avoid repeated steering.
    if(result.before.intrusions==result.after.intrusions &&
       result.before.field-result.after.field<25)result.modified=false;
    return result;
}
}
