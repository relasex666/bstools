#pragma once
#include <cstdint>
#include <cstddef>
uint64_t bstools_module_base();
bool bstools_read(uint64_t address,void* output,size_t size);
template<class T> bool bstools_read(uint64_t address,T& output) {
    return bstools_read(address,&output,sizeof(output));
}
