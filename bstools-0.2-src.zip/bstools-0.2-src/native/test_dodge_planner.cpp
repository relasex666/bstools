#include "dodge_planner.h"
#include <iostream>
#include <cstdlib>
using namespace bstools_dodge;
unsigned passed=0;
void check(const char* name,bool ok){
    if(!ok){std::cerr<<"FAIL "<<name<<'\n';std::exit(1);}
    std::cout<<"PASS "<<name<<'\n';++passed;
}
int main(){
    std::array<Threat,32> threats{};std::array<Enemy,8> enemies{};
    auto free=[](Vec){return true;};
    threats[0]={{1000,0},{-1500,0},150};
    auto result=solve(threats,1,enemies,0,{},720,{},false,free);
    check("incoming avoided",result.modified && result.after.intrusions==0 && result.before.intrusions==1);
    check("121 refuge cells evaluated",result.cells==121);
    auto blocked=solve(threats,1,enemies,0,{},720,{},false,[](Vec){return false;});
    check("blocked movement rejected",!blocked.modified && blocked.cells==0);
    auto manual=solve(threats,1,enemies,0,{0,720},720,{},false,free);
    check("safe observed movement preserved",!manual.modified && manual.before.intrusions==0);
    threats[0]={{1000,0},{1000,0},150};
    check("outgoing bullet ignored",!solve(threats,1,enemies,0,{},720,{},false,free).modified);
    threats[0]={{1000,0},{-20000,0},80};
    check("fast projectile does not tunnel",clearance(threats[0],toward({},720),.1)<0);
    Path slow=toward({850,0},100);
    check("unreachable refuge never teleports",std::abs(slow.at(.9).x-90)<1e-6 && slow.arrival>8);
    threats[0]={{1000,0},{-1000,0},150};
    check("arrival stop remains in collision test",clearance(threats[0],toward({0,50},1000),1.5)
         <clearance(threats[0],toward({0,1500},1000),1.5));
    threats[0]={{800,0},{-1000,0},150};threats[1]={{-800,0},{1000,0},150};
    result=solve(threats,2,enemies,0,{},720,{},false,free);
    check("two projectile crossfire avoided",result.modified && result.after.intrusions==0);
    threats[0]={{0,0},{1000,0},450};
    result=solve(threats,1,enemies,0,{},720,{},false,free);
    check("initial overlap can escape",result.modified && result.after.field<result.before.field);
    check("collision count outranks soft costs",better({0,1e15,0},{1,-1e15,0}));
    threats[0]={{800,0},{-1000,0},150};
    result=solve(threats,1,enemies,0,{},720,{},false,[](Vec p){return p.y>=-1e-6;});
    check("wall filter constrains escape",result.modified && result.destination.y>=-1e-6);
    std::array<Threat,32> wide=threats;wide[0].radius=800;
    auto narrow_score=evaluate(threats,1,enemies,0,toward({0,600},720),.9);
    auto wide_score=evaluate(wide,1,enemies,0,toward({0,600},720),.9);
    check("radius changes collision envelope",narrow_score.intrusions<wide_score.intrusions);
    Threat urgent{{500,0},{-3000,0},100};
    check("input delay participates in collision test",clearance(urgent,toward({0,600},720,{},.12),.3)
        <0 && clearance(urgent,toward({0,600},720),.3)>0);
    const auto delayed=toward({0,600},720,{100,0},.1);
    check("existing motion continues until command arrival",std::abs(delayed.at(.05).x-5)<1e-6);
    std::cout<<"TOTAL "<<passed<<" passed\n";
}
