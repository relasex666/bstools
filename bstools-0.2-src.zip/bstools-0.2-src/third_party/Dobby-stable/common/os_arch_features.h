#pragma once

#include <cstdint>

#include <sys/types.h>
#include <stddef.h>
#if defined(ANDROID)
#include <unistd.h>
#include <sys/mman.h>
#endif
#include "pac_kit.h"

#include "PlatformUnifiedInterface/platform.h"

#if defined(__arm64e__) && __has_feature(ptrauth_calls)
#include <ptrauth.h>
#endif

namespace features {

template <typename T> inline T arm_thumb_fix_addr(T &addr) {
  addr = (T)((uintptr_t)addr & ~1);
  return addr;
}

namespace apple {
template <typename T> inline T arm64e_pac_strip(T &addr) {
  return pac_strip(addr);
}

template <typename T> inline T arm64e_pac_sign(T &addr) {
  return pac_sign(addr);
}

template <typename T> inline T arm64e_pac_strip_and_sign(T &addr) {
  return pac_strip_and_sign(addr);
}
} // namespace apple

namespace android {
inline void make_memory_readable(void *address, size_t size) {
#if defined(ANDROID)
  // Local Android fix: avoid platform.h's circular dependency during parsing.
  const size_t page_size = static_cast<size_t>(sysconf(_SC_PAGESIZE));
  auto page = reinterpret_cast<void *>(reinterpret_cast<uintptr_t>(address) & ~(page_size - 1));
  if (mprotect(page, page_size, PROT_READ | PROT_EXEC) != 0) return;
#endif
}
} // namespace android
} // namespace features