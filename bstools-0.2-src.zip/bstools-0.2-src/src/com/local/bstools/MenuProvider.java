package com.local.bstools;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.WeakHashMap;

/** BS Tools menu: native-game popup layout, existing game fonts, local controls. */
public final class MenuProvider extends ContentProvider {
    public boolean onCreate() {
        try {
            Application app=(Application)getContext().getApplicationContext();
            if (!"69.230".equals(app.getPackageManager().getPackageInfo(app.getPackageName(),0).versionName)) return true;
            app.registerActivityLifecycleCallbacks(new Callbacks());
        } catch(Throwable e){android.util.Log.e("BSTools","Menu initialization failed",e);}
        return true;
    }
    public Cursor query(Uri u,String[] p,String s,String[] a,String o){return null;}
    public String getType(Uri u){return null;}
    public Uri insert(Uri u,ContentValues v){return null;}
    public int delete(Uri u,String s,String[] a){return 0;}
    public int update(Uri u,ContentValues v,String s,String[] a){return 0;}

    static final class Callbacks implements Application.ActivityLifecycleCallbacks {
        final WeakHashMap<Activity,Panel> panels=new WeakHashMap<>();
        public void onActivityResumed(Activity a){
            if(!a.getClass().getName().startsWith("com.supercell."))return;
            try{Panel old=panels.remove(a);if(old!=null)old.dispose();panels.put(a,new Panel(a));}
            catch(Throwable e){android.util.Log.e("BSTools","Menu could not be shown",e);}
        }
        public void onActivityPaused(Activity a){Panel p=panels.remove(a);if(p!=null)p.dispose();}
        public void onActivityDestroyed(Activity a){onActivityPaused(a);}
        public void onActivityCreated(Activity a,Bundle b){}
        public void onActivityStarted(Activity a){}
        public void onActivityStopped(Activity a){}
        public void onActivitySaveInstanceState(Activity a,Bundle b){}
    }

    static final class EspOverlay extends View implements Runnable {
        final Handler handler=new Handler(Looper.getMainLooper());
        final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        JSONObject frame=new JSONObject();JSONArray boxes=new JSONArray();
        boolean disposed;int flags=63,color=0xFF58E4FF;
        EspOverlay(Activity a){super(a);setClickable(false);setFocusable(false);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        public void run(){
            if(disposed)return;
            try{frame=new JSONObject(MenuBridge.espSnapshot());boxes=frame.optJSONArray("boxes");}
            catch(Throwable e){boxes=null;}
            invalidate();handler.postDelayed(this,80);
        }
        protected void onDraw(Canvas canvas){
            super.onDraw(canvas);if(boxes==null)return;
            final float d=getResources().getDisplayMetrics().density;
            final float ax=(float)frame.optDouble("anchorX",.5)*getWidth();
            final float ay=(float)frame.optDouble("anchorY",.96)*getHeight();
            for(int i=0;i<boxes.length();i++)try{
                JSONObject b=boxes.getJSONObject(i);
                float l=(float)b.getDouble("l")*getWidth(),r=(float)b.getDouble("r")*getWidth();
                float t=(float)b.getDouble("t")*getHeight(),bottom=(float)b.getDouble("b")*getHeight();
                boolean enemy=b.optBoolean("enemy",false);
                pen.setShadowLayer(0,0,0,0);pen.setStyle(Paint.Style.STROKE);
                if((flags&4)!=0&&enemy){
                    float fx=(float)b.optDouble("fx",(b.getDouble("l")+b.getDouble("r"))*.5)*getWidth();
                    float fy=(float)b.optDouble("fy",b.getDouble("b"))*getHeight();
                    pen.setColor(0xCC061427);pen.setStrokeWidth(3.5f*d);canvas.drawLine(ax,ay,fx,fy,pen);
                    pen.setColor(color);pen.setStrokeWidth(1.4f*d);canvas.drawLine(ax,ay,fx,fy,pen);
                    pen.setStyle(Paint.Style.FILL);canvas.drawCircle(fx,fy,2.6f*d,pen);
                }
                if((flags&1)!=0){
                    pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(2*d);pen.setColor(color);
                    canvas.drawRoundRect(l,t,r,bottom,3*d,3*d,pen);
                }
                if((flags&2)!=0){
                    pen.setStyle(Paint.Style.FILL);pen.setColor(0xDA071329);canvas.drawRect(l,t-8*d,r,t-3*d,pen);
                    float ratio=Math.min(1f,Math.max(0f,(float)b.getInt("hp")/Math.max(1,b.getInt("max"))));
                    pen.setColor(0xFF8BEE58);canvas.drawRect(l,t-8*d,l+(r-l)*ratio,t-3*d,pen);
                    pen.setColor(Color.WHITE);pen.setTextSize(11*d);pen.setShadowLayer(2*d,0,d,Color.BLACK);
                    canvas.drawText(Integer.toString(b.getInt("hp")),l,t-11*d,pen);
                }
                if((flags&8)!=0){
                    pen.setStyle(Paint.Style.FILL);pen.setColor(Color.WHITE);pen.setTextSize(10*d);
                    pen.setShadowLayer(2*d,0,d,Color.BLACK);
                    canvas.drawText(String.format(Locale.US,"%.1f kare",b.optDouble("distanceTiles")),l,bottom+13*d,pen);
                }
                if((flags&32)!=0 && b.optDouble("ammoCharge",-1)>=0){
                    pen.setStyle(Paint.Style.FILL);pen.setColor(0xFFFFD66C);pen.setTextSize(10*d);pen.setShadowLayer(2*d,0,d,Color.BLACK);
                    canvas.drawText(String.format(Locale.US,"Mermi %.1f",b.optDouble("ammoCharge")),l,bottom+((flags&8)!=0?26:13)*d,pen);
                }
                pen.clearShadowLayer();
            }catch(Exception ignored){}
        }
        void dispose(){disposed=true;handler.removeCallbacks(this);if(getParent() instanceof ViewGroup)((ViewGroup)getParent()).removeView(this);}
    }

    static final class Panel implements Runnable {
        final Activity owner;final SharedPreferences prefs;
        final Handler handler=new Handler(Looper.getMainLooper());
        final ViewGroup parent;final FrameLayout layer,modal;
        final LinearLayout box,content,pages,nav;
        final Button toggle,close,aim,autoFire,ulti,wall,esp,dodge,lines,boxes,health,distance,enemyOnly,ammo;
        final Button origin,color;
        final TextView info,battleStatus,summary;
        final EspOverlay overlay;final Typeface headingFont,bodyFont;
        final LinearLayout[] panels=new LinearLayout[4];
        final String[] tabs={"ANA SAYFA","ÖZELLİKLER","MOD AYARLARI","HAKKINDA"};
        boolean open,disposed,showCoordinates;int selected=0,espFlags,espOrigin,colorIndex;
        final int[] colors={0xFF58E4FF,0xFF91F261,0xFFFFD361,0xFFFF82CF};
        final String[] colorNames={"BUZ MAVİSİ","YEŞİL","ALTIN","PEMBE"};
        int dp(float n){return (int)(n*owner.getResources().getDisplayMetrics().density+.5f);}
        GradientDrawable surface(int a,int b,int stroke,int radius){
            GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{a,b});
            shape.setCornerRadius(dp(radius));shape.setStroke(dp(2),stroke);return shape;
        }
        Typeface font(String path,Typeface fallback){try{return Typeface.createFromAsset(owner.getAssets(),path);}catch(Throwable e){return fallback;}}
        TextView text(String value,int size,int color,boolean headline){
            TextView t=new TextView(owner);t.setText(value);t.setTextSize(size);t.setTextColor(color);
            t.setTypeface(headline?headingFont:bodyFont);t.setLineSpacing(dp(2),1);return t;
        }
        Button button(String value){
            Button b=new Button(owner);b.setText(value);b.setAllCaps(false);b.setTextSize(14);b.setTypeface(headingFont);
            b.setTextColor(Color.WHITE);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);
            b.setPadding(dp(10),dp(6),dp(10),dp(6));b.setElevation(dp(2));
            b.setBackground(surface(0xFF2F8ADF,0xFF1656A5,0xFF071C3C,7));
            b.setOnTouchListener(new View.OnTouchListener(){public boolean onTouch(View v,MotionEvent e){
                float scale=e.getActionMasked()==MotionEvent.ACTION_DOWN?.97f:1;
                v.animate().scaleX(scale).scaleY(scale).setDuration(90).start();return false;
            }});return b;
        }
        void paint(Button b,boolean active){
            b.setText(active?"AÇIK":"KAPALI");b.setTextColor(active?0xFF133600:0xFFEAF1FF);
            b.setBackground(surface(active?0xFFB7F64B:0xFF587396,active?0xFF66BE23:0xFF344B6E,0xFF071B36,6));
        }
        void section(LinearLayout page,String title){
            TextView t=text(title,16,0xFFFFD467,true);t.setShadowLayer(dp(1),0,dp(1),0xFF081A34);
            t.setPadding(dp(3),dp(12),0,dp(8));page.addView(t);
        }
        Button row(LinearLayout page,String title,String description){
            LinearLayout row=new LinearLayout(owner);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(10),dp(8));
            row.setBackground(surface(0xFF28548C,0xFF214471,0xFF102A50,7));row.setMinimumHeight(dp(63));
            LinearLayout labels=new LinearLayout(owner);labels.setOrientation(LinearLayout.VERTICAL);
            labels.addView(text(title,16,Color.WHITE,true));
            if(!description.isEmpty())labels.addView(text(description,10,0xFFB9D5F6,false));
            row.addView(labels,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
            Button control=button("KAPALI");row.addView(control,new LinearLayout.LayoutParams(dp(83),dp(35)));
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,-2);size.bottomMargin=dp(6);page.addView(row,size);
            row.setOnClickListener(new View.OnClickListener(){public void onClick(View v){control.performClick();}});
            paint(control,false);return control;
        }
        void note(LinearLayout page,String value){TextView t=text(value,11,0xFFBCD5F5,false);t.setPadding(dp(4),dp(6),dp(4),dp(10));page.addView(t);}
        void applyEsp(){
            try{MenuBridge.setEspOptions(espFlags,espOrigin);}catch(Throwable ignored){}
            overlay.flags=espFlags;overlay.color=colors[colorIndex];
            prefs.edit().putInt("espFlags",espFlags).putInt("espOrigin",espOrigin).putInt("espColor",colorIndex).apply();
        }
        void bindFlag(final Button button,final int flag){button.setOnClickListener(new View.OnClickListener(){public void onClick(View v){espFlags^=flag;applyEsp();refresh();}});}
        void setOpen(boolean value){
            open=value;modal.animate().cancel();box.animate().cancel();
            if(value){
                toggle.setVisibility(View.GONE);modal.setVisibility(View.VISIBLE);modal.setAlpha(0);
                box.setScaleX(.94f);box.setScaleY(.94f);box.setTranslationY(dp(12));
                modal.animate().alpha(1).setDuration(160).start();
                box.animate().scaleX(1).scaleY(1).translationY(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
                handler.removeCallbacks(this);run();
            }else{
                handler.removeCallbacks(this);
                modal.animate().alpha(0).setDuration(130).withEndAction(new Runnable(){public void run(){if(!open){modal.setVisibility(View.GONE);toggle.setVisibility(View.VISIBLE);}}}).start();
            }
        }
        void select(int index){
            selected=index;
            for(int i=0;i<panels.length;i++){
                panels[i].setVisibility(i==index?View.VISIBLE:View.GONE);
                Button b=(Button)nav.getChildAt(i);
                b.setTextColor(i==index?0xFF203600:Color.WHITE);
                b.setBackground(surface(i==index?0xFFD2F95C:0xFF3475B9,i==index?0xFF8AC92A:0xFF204B80,0xFF0A234A,6));
            }
            panels[index].setAlpha(0);panels[index].setTranslationY(dp(7));
            panels[index].animate().alpha(1).translationY(0).setDuration(160).start();
            final ScrollView scroll=(ScrollView)content.getChildAt(1);
            scroll.scrollTo(0,0);
            scroll.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(){public void onGlobalLayout(){
                scroll.getViewTreeObserver().removeOnGlobalLayoutListener(this);scroll.scrollTo(0,0);
            }});
            panels[index].requestLayout();
        }
        void alphaSlider(LinearLayout page,String label,final String key,int initial,final View view,int minimum){
            TextView title=text(label,13,Color.WHITE,false);title.setPadding(dp(4),dp(9),0,dp(3));page.addView(title);
            SeekBar bar=new SeekBar(owner);bar.setMax(255-minimum);bar.setProgress(initial-minimum);page.addView(bar,new LinearLayout.LayoutParams(-1,dp(30)));
            final int min=minimum;bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar b,int progress,boolean user){if(user){int value=progress+min;view.setAlpha(value/255f);prefs.edit().putInt(key,value).apply();}}
                public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
            });
        }
        Panel(Activity activity){
            owner=activity;prefs=owner.getPreferences(0);
            headingFont=font("font/LilitaOne-Regular.ttf",Typeface.DEFAULT_BOLD);
            bodyFont=font("flutter_assets/packages/scid_flutter/fonts/SupercellText_Md.ttf",Typeface.DEFAULT);
            showCoordinates=prefs.getBoolean("showCoordinates",true);espFlags=prefs.getInt("espFlags",63)&63;
            espOrigin=Math.max(0,Math.min(2,prefs.getInt("espOrigin",0)));colorIndex=Math.max(0,Math.min(3,prefs.getInt("espColor",0)));
            parent=(ViewGroup)owner.getWindow().getDecorView();overlay=new EspOverlay(owner);
            parent.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
            layer=new FrameLayout(owner);parent.addView(layer,new FrameLayout.LayoutParams(-1,-1));
            toggle=button("BS 0.2");toggle.setTextSize(15);toggle.setBackground(surface(0xFF44B9FF,0xFF1B66C0,0xFF082448,9));
            FrameLayout.LayoutParams floating=new FrameLayout.LayoutParams(dp(125),dp(43),Gravity.RIGHT|Gravity.TOP);
            floating.topMargin=dp(52);floating.rightMargin=dp(14);layer.addView(toggle,floating);
            toggle.setAlpha(prefs.getInt("buttonAlpha",255)/255f);
            toggle.setOnClickListener(new View.OnClickListener(){public void onClick(View v){setOpen(true);}});
            modal=new FrameLayout(owner);modal.setBackgroundColor(0xA0071022);modal.setVisibility(View.GONE);layer.addView(modal,new FrameLayout.LayoutParams(-1,-1));
            modal.setOnClickListener(new View.OnClickListener(){public void onClick(View v){setOpen(false);}});
            box=new LinearLayout(owner);box.setOrientation(LinearLayout.VERTICAL);box.setClickable(true);box.setElevation(dp(12));
            box.setPadding(dp(5),dp(5),dp(5),dp(5));box.setBackground(surface(0xFF479FED,0xFF153D77,0xFF071831,11));
            int width=Math.min(dp(650),(int)(owner.getResources().getDisplayMetrics().widthPixels*.91));
            int height=Math.min(dp(470),(int)(owner.getResources().getDisplayMetrics().heightPixels*.9));
            FrameLayout.LayoutParams popup=new FrameLayout.LayoutParams(width,height,Gravity.CENTER);modal.addView(box,popup);
            LinearLayout header=new LinearLayout(owner);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),0,dp(5),0);
            header.setBackground(surface(0xFF3697EC,0xFF1D64B5,0xFF143F7A,7));box.addView(header,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView brand=text("BS 0.2",27,Color.WHITE,true);brand.setShadowLayer(dp(2),0,dp(2),0xFF061B3A);
            header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
            TextView build=text("RAMBO",13,0xFFFFDC67,true);build.setPadding(0,0,dp(16),0);header.addView(build);
            close=button("×");close.setTextSize(26);close.setPadding(0,0,0,0);close.setBackground(surface(0xFFFF7F69,0xFFD93D3C,0xFF6B1725,7));
            header.addView(close,new LinearLayout.LayoutParams(dp(42),dp(38)));close.setOnClickListener(new View.OnClickListener(){public void onClick(View v){setOpen(false);}});
            content=new LinearLayout(owner);content.setOrientation(LinearLayout.VERTICAL);box.addView(content,new LinearLayout.LayoutParams(-1,0,1));
            nav=new LinearLayout(owner);nav.setPadding(dp(3),dp(7),dp(3),dp(6));content.addView(nav,new LinearLayout.LayoutParams(-1,dp(46)));
            for(int i=0;i<tabs.length;i++){
                final int tab=i;Button b=button(tabs[i]);b.setTextSize(12);b.setPadding(dp(2),0,dp(2),0);
                LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(0,-1,1);size.rightMargin=i==tabs.length-1?0:dp(5);nav.addView(b,size);
                b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){select(tab);}});
            }
            ScrollView scroll=new ScrollView(owner);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setBackground(surface(0xFF13315E,0xFF102950,0xFF0B2346,6));
            content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
            pages=new LinearLayout(owner);pages.setPadding(dp(12),dp(4),dp(12),dp(10));pages.setOrientation(LinearLayout.VERTICAL);scroll.addView(pages);
            for(int i=0;i<panels.length;i++){panels[i]=new LinearLayout(owner);panels[i].setOrientation(LinearLayout.VERTICAL);pages.addView(panels[i],new LinearLayout.LayoutParams(-1,-2));}
            section(panels[0],"OYUNA HAZIR");
            TextView intro=text("Savaş kontrolü tek yerde.",23,Color.WHITE,true);intro.setPadding(dp(4),dp(5),0,dp(8));panels[0].addView(intro);
            note(panels[0],"Özellikler'den savaş yardımcılarını aç. Mod Ayarları'ndan ESP çizimini ve görünümü düzenle.");
            info=text("Karakter bekleniyor",15,Color.WHITE,false);info.setPadding(dp(14),dp(12),dp(14),dp(12));
            info.setBackground(surface(0xFF28588B,0xFF204775,0xFF0B244A,7));panels[0].addView(info,new LinearLayout.LayoutParams(-1,-2));
            summary=text("",12,0xFFB9D7F5,false);summary.setPadding(dp(5),dp(12),dp(5),dp(12));panels[0].addView(summary);
            Button go=button("SAVAŞ ÖZELLİKLERİNİ AÇ");panels[0].addView(go,new LinearLayout.LayoutParams(-1,dp(43)));go.setOnClickListener(new View.OnClickListener(){public void onClick(View v){select(1);}});
            section(panels[1],"SAVAŞ");
            aim=row(panels[1],"Aimbot","Silahının menzilindeki rakip oyunculara nişan alır.");
            autoFire=row(panels[1],"Otomatik saldırı","Mermi hazır olduğunda uygun rakibe ateş eder.");
            ulti=row(panels[1],"Otomatik ulti","Ulti doluluğunu ve kendi menzilini denetler.");
            wall=row(panels[1],"Duvar kontrolü","Duvar arkasındaki otomatik hedefleri eler.");
            section(panels[1],"HAREKET VE GÖRÜŞ");
            dodge=row(panels[1],"Dodge","Çoklu mermi takibi ve kaçış yönü seçimi.");
            esp=row(panels[1],"ESP","Çizgi, kutu, can ve mesafe görünümü.");
            battleStatus=text("Her savaşta önce bir kez normal ateş et.",11,0xFFFFDB72,false);panels[1].addView(battleStatus);
            aim.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.setAimEnabled(!new JSONObject(MenuBridge.aimState()).optBoolean("enabled"));refresh();}catch(Throwable e){battleStatus.setText("Nişan bağlantısı kurulamadı");}}});
            autoFire.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.setAutoFireEnabled(!new JSONObject(MenuBridge.autoFireState()).optBoolean("enabled"));refresh();}catch(Throwable e){battleStatus.setText("Saldırı bağlantısı kurulamadı");}}});
            ulti.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.setAutoSuperEnabled(!new JSONObject(MenuBridge.autoFireState()).optBoolean("superEnabled"));refresh();}catch(Throwable e){battleStatus.setText("Ulti bağlantısı kurulamadı");}}});
            wall.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.setWallCheckEnabled(!new JSONObject(MenuBridge.autoFireState()).optBoolean("wallCheck",true));refresh();}catch(Throwable e){battleStatus.setText("Duvar kontrolü değiştirilemedi");}}});
            dodge.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.setDodgeEnabled(!new JSONObject(MenuBridge.autoFireState()).optBoolean("dodgeEnabled"));refresh();}catch(Throwable e){battleStatus.setText("Dodge başlatılamadı");}}});
            esp.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{applyEsp();MenuBridge.setEspEnabled(!new JSONObject(MenuBridge.espSnapshot()).optBoolean("enabled"));refresh();}catch(Throwable e){battleStatus.setText("ESP başlatılamadı");}}});
            section(panels[2],"ESP GÖRÜNÜMÜ");
            lines=row(panels[2],"ESP Line","Rakibin konumuna çizgi çizer.");
            boxes=row(panels[2],"Kutu","Karakterin etrafında çerçeve gösterir.");
            health=row(panels[2],"Can çubuğu","Can değerini ve doluluk çubuğunu gösterir.");
            ammo=row(panels[2],"Rakip mermi doluluğu","Desteklenen normal silahın bildirilen doluluğu.");
            distance=row(panels[2],"Mesafe","Uzaklığı harita karesi olarak gösterir.");
            enemyOnly=row(panels[2],"Yalnızca rakip oyuncular","Kutu, tarafsız nesne ve oyuncu olmayanları eler.");
            bindFlag(lines,4);bindFlag(boxes,1);bindFlag(health,2);bindFlag(ammo,32);bindFlag(distance,8);bindFlag(enemyOnly,16);
            origin=button("");LinearLayout.LayoutParams optionSize=new LinearLayout.LayoutParams(-1,dp(40));optionSize.bottomMargin=dp(7);panels[2].addView(origin,optionSize);
            origin.setOnClickListener(new View.OnClickListener(){public void onClick(View v){espOrigin=(espOrigin+1)%3;applyEsp();refresh();}});
            color=button("");panels[2].addView(color,new LinearLayout.LayoutParams(-1,dp(40)));
            color.setOnClickListener(new View.OnClickListener(){public void onClick(View v){colorIndex=(colorIndex+1)%colors.length;applyEsp();refresh();}});
            section(panels[2],"MENÜ GÖRÜNÜMÜ");
            final Button coordinates=row(panels[2],"Konum bilgisi","Ana sayfada karakter koordinatlarını gösterir.");paint(coordinates,showCoordinates);
            coordinates.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showCoordinates=!showCoordinates;prefs.edit().putBoolean("showCoordinates",showCoordinates).apply();paint(coordinates,showCoordinates);refresh();}});
            alphaSlider(panels[2],"Menü butonu saydamlığı","buttonAlpha",Math.max(64,prefs.getInt("buttonAlpha",255)),toggle,64);
            int menuAlpha=Math.max(128,prefs.getInt("menuAlpha",255));box.setAlpha(menuAlpha/255f);
            alphaSlider(panels[2],"Pencere saydamlığı","menuAlpha",menuAlpha,box,128);
            section(panels[3],"BS 0.2");
            note(panels[3],"BS 0.2\nGeliştirici: Rambo\n\nAimbot · Otomatik saldırı · Ulti\nDodge · ESP Line\n\nOyun sürümü: 69.230");
            note(panels[3],"Savaş özelliklerini Özellikler sekmesinden, çizim ve renk seçeneklerini Mod Ayarları sekmesinden yönetebilirsin.");
            LinearLayout footer=new LinearLayout(owner);footer.setPadding(dp(5),dp(6),dp(5),dp(2));box.addView(footer,new LinearLayout.LayoutParams(-1,dp(45)));
            Button stop=button("TÜMÜNÜ KAPAT");stop.setTextSize(13);stop.setBackground(surface(0xFFE46B58,0xFFBC343A,0xFF6C1E2D,6));footer.addView(stop,new LinearLayout.LayoutParams(0,-1,1));
            stop.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{MenuBridge.disableAll();refresh();}catch(Throwable ignored){}}});
            Button back=button("OYUNA DÖN");back.setTextSize(13);LinearLayout.LayoutParams backSize=new LinearLayout.LayoutParams(0,-1,1);backSize.leftMargin=dp(8);footer.addView(back,backSize);
            back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){setOpen(false);}});
            applyEsp();select(0);overlay.run();refresh();
        }
        void refresh(){
            if(disposed)return;
            try{
                JSONObject a=new JSONObject(MenuBridge.aimState()),f=new JSONObject(MenuBridge.autoFireState()),e=new JSONObject(MenuBridge.espSnapshot()),s=new JSONObject(MenuBridge.snapshot());
                paint(aim,a.optBoolean("enabled"));paint(autoFire,f.optBoolean("enabled"));paint(ulti,f.optBoolean("superEnabled"));
                paint(wall,f.optBoolean("wallCheck",true));paint(dodge,f.optBoolean("dodgeEnabled"));paint(esp,e.optBoolean("enabled"));
                if(f.optInt("dodgeStatus")==2)battleStatus.setText("Bu maç biçiminde Dodge hareketi desteklenmiyor.");
                paint(lines,(espFlags&4)!=0);paint(boxes,(espFlags&1)!=0);paint(health,(espFlags&2)!=0);paint(ammo,(espFlags&32)!=0);paint(distance,(espFlags&8)!=0);paint(enemyOnly,(espFlags&16)!=0);
                origin.setText("ÇİZGİ BAŞLANGICI: "+new String[]{"KARAKTERİM","EKRAN ALTI","EKRAN ÜSTÜ"}[espOrigin]);
                color.setText("ESP RENGİ: "+colorNames[colorIndex]);color.setTextColor(colors[colorIndex]);
                info.setText(s.has("health")?"CAN  "+s.optInt("health")+" / "+s.optInt("maxHealth")+(showCoordinates?"\nKONUM  "+s.optInt("x")+" / "+s.optInt("y"):""):"Karakter bekleniyor\nSavaşta bir kez normal ateş et.");
                summary.setText("Dodge hareketi  "+f.optInt("dodgeMoves")+"     İzlenen mermi  "+f.optInt("dodgeThreats")+"\nESP hedefi  "+(e.optJSONArray("boxes")==null?0:e.optJSONArray("boxes").length()));
            }catch(Throwable error){info.setText("Oyun bağlantısı bekleniyor");}
        }
        public void run(){if(disposed||!open)return;refresh();handler.removeCallbacks(this);handler.postDelayed(this,500);}
        void dispose(){disposed=true;handler.removeCallbacks(this);overlay.dispose();parent.removeView(layer);}
    }
}
