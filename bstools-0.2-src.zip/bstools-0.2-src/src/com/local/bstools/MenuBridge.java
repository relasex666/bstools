package com.local.bstools;

public final class MenuBridge {
    static { System.loadLibrary("bstools_readonly"); }
    private MenuBridge() {}
    public static native String snapshot();
    public static native String setAimEnabled(boolean enabled);
    public static native String disableAll();
    public static native String aimState();
    public static native String previewAim();
    public static native String setAutoFireEnabled(boolean enabled);
    public static native String autoFireState();
    public static native String setAutoSuperEnabled(boolean enabled);
    public static native String setWallCheckEnabled(boolean enabled);
    public static native String setEspEnabled(boolean enabled);
    public static native String espSnapshot();
    public static native String setEspOptions(int flags, int origin);
    public static native String setDodgeEnabled(boolean enabled);
    public static native String dodgePlannerCheck();
    public static native String targetFilterCheck();
}
