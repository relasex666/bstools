"""Build a signed diagnostics-menu APK. Does not install or replace the game."""
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path
from patch_manifest import patch
from native_build import build_native

ROOT = Path(__file__).resolve().parent
from build_config import INPUT, SDK, JAVA
BUILD = ROOT / 'build'
BUILD.mkdir(exist_ok=True)
TOOLS = SDK / 'build-tools/36.0.0'
ANDROID = SDK / 'platforms/android-37.0/android.jar'

def run(args):
    subprocess.run([str(x) for x in args], check=True)

classes = BUILD / 'classes'; classes.mkdir(exist_ok=True)
run([JAVA/'javac.exe', '-encoding', 'UTF-8', '-source', '8', '-target', '8',
     '-bootclasspath', ANDROID, '-d', classes, *ROOT.glob('src/**/*.java')])
dex = BUILD / 'dex'; dex.mkdir(exist_ok=True)
run([JAVA/'java.exe', '-cp', TOOLS/'lib/d8.jar', 'com.android.tools.r8.D8',
     '--min-api', '32', '--lib', ANDROID, '--output', dex, *classes.rglob('*.class')])
library = BUILD / 'libbstools_readonly.so'
build_native(library)
unsigned = BUILD / 'base-menu-unsigned.apk'
with zipfile.ZipFile(INPUT) as source, zipfile.ZipFile(unsigned, 'w', allowZip64=True) as output:
    names = source.namelist()
    dex_numbers = [int(m.group(1) or '1') for name in names
                   if (m := re.fullmatch(r'classes(\d*)\.dex', name))]
    next_dex = f'classes{max(dex_numbers, default=0)+1}.dex'
    manifest = patch(source.read('AndroidManifest.xml'))
    print('Manifest patched without changing original attributes; extra DEX:', next_dex, flush=True)
    for entry in source.infolist():
        if re.match(r'META-INF/[^/]+\.(SF|RSA|DSA|EC)$', entry.filename, re.I) or entry.filename == 'META-INF/MANIFEST.MF':
            continue
        if entry.filename == 'AndroidManifest.xml':
            output.writestr(entry, manifest)
        else:
            with source.open(entry) as src, output.open(entry, 'w') as dst:
                shutil.copyfileobj(src, dst, 4*1024*1024)
    output.write(dex/'classes.dex', next_dex, compress_type=zipfile.ZIP_DEFLATED)
    output.write(library, 'lib/arm64-v8a/libbstools_readonly.so', compress_type=zipfile.ZIP_STORED)
aligned = BUILD / 'base-menu-aligned.apk'
run([TOOLS/'zipalign.exe', '-P', '16', '-f', '4', unsigned, aligned])
key = ROOT / 'local-debug.keystore'
if not key.exists():
    run([JAVA/'keytool.exe', '-genkeypair', '-keystore', key, '-storepass', 'android',
         '-keypass', 'android', '-alias', 'local-menu', '-keyalg', 'RSA', '-keysize', '2048',
         '-validity', '3650', '-dname', 'CN=Local diagnostics menu', '-noprompt'])
result = ROOT / 'base-autofire-69.230.apk'
run([JAVA/'java.exe', '-jar', TOOLS/'lib/apksigner.jar', 'sign', '--ks', key,
     '--ks-key-alias', 'local-menu', '--ks-pass', 'pass:android', '--key-pass', 'pass:android',
     '--out', result, aligned])
run([JAVA/'java.exe', '-jar', TOOLS/'lib/apksigner.jar', 'verify', '--verbose', result])
run([TOOLS/'zipalign.exe', '-c', '-P', '16', '4', result])
with result.open('rb') as stream:
    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
(ROOT/'build-report.json').write_text(json.dumps({
    'output': str(result), 'sha256': digest, 'signature_verified': True, 'alignment_verified': True,
    'runtime_tested': False, 'installed': False,
    'features': ['four-tab blue BS Tools popup using existing game fonts and saved visual options', 'primary and own type-2 super aim redirection; initially OFF',
                 'native line-of-sight target filtering; initially ON', 'configurable ESP line/box/HP/distance/primary-charge overlay with enemy-player filter; initially OFF',
                 'experimental sampled-projectile dodge for unsigned movement input modes; initially OFF',
                 'roster and skill based enemy-player aim filtering; neutral NPCs excluded',
                 'experimental game-thread automatic primary attack and super; initially OFF; one manual shot per battle required'],
    'aim_user_reported_working': True, 'autofire_live_tested': False,
    'primary_charge_gate': 'type 1; charge >999; ECE92C active/cooldown/disabled checks; alternate data rejected',
    'super_gate': 'player +148 == +152 with positive max; type 2 skill ready; one accepted attempt until meter drops',
    'super_live_tested': False, 'dodge_implemented': True, 'dodge_live_movement_tested': False, 'esp_implemented': True, 'esp_live_render_tested': False, 'esp_line_synthetic_render_tested': False, 'menu_style': 'four-tab game-style Android popup',
    'target_filter': 'enemy team >=0; valid roster index and player; primary and super skills required',
    'dodge_planner': 'refuge-v7plus', 'dodge_max_candidates': 121,
    'dodge_candidate_distances': [0,60,130,220,350,500,600,850],
    'dodge_geometry_host_checks_passed': 15, 'skill_metadata_host_checks_passed': 16,
    'aim_range': 'current selected skill CastingRange CSV column; units * 100; primary and super independent',
    'dodge_collision_radius_source': '69.230 character data +0x2ac and projectile data +0x130 with 45-unit padding; unreadable data falls back to 450',
    'dodge_observation_ms': 16, 'dodge_movement_cooldown_ms': 60, 'dodge_model_input_delay_ms': 60,
    'dodge_comparative_effectiveness_measured': False,
    'hook_and_instrument_probe_passed': True,
    'full_switchgear_or_revenge': False, 'source_apk_unchanged': True}, indent=2), encoding='utf-8')
print('Built:', result, flush=True)
