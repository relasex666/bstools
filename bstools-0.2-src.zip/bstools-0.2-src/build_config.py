from pathlib import Path
import os
ROOT = Path(__file__).resolve().parent
SDK = Path(os.environ.get('ANDROID_SDK_ROOT', str(Path.home() / 'AppData/Local/Android/Sdk')))
JAVA = Path(os.environ.get('JAVA_HOME', '')) / 'bin'
if not (JAVA / 'javac.exe').is_file():
    raise RuntimeError('Set JAVA_HOME to your JDK directory before building.')
INPUT = Path(os.environ.get('BSTOOLS_INPUT_APK', str(ROOT / 'input/base.apk')))
NDK = SDK / 'ndk/30.0.16248370'
CMAKE = SDK / 'cmake/4.1.2/bin/cmake.exe'
