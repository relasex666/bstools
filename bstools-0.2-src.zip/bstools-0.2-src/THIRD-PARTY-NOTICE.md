# Dobby

Source: https://github.com/jmpews/Dobby

Pinned source used by native_build.py: 49c3a653bd54613a75632caeed27f824e56192dd.

License: Apache License 2.0, retained at third_party/Dobby-stable/LICENSE.

Local changes in the pinned source:

- ARM64 closure assembly: ELF relocations and hidden internal handler on Android; Mach-O form retained for Apple.
- POSIX code patcher: repaired ClearCache header include and checked writable mapping failures before memcpy.
- Android memory-readability helper: removed circular OSMemory dependency using the same page protection operation via POSIX.
- Linux runtime enumeration: updated MemRange start accessor and RuntimeModule base member to their declared names.

The separate third_party/Dobby checkout was an initial build investigation and is not used by native_build.py.
